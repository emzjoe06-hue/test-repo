const { exec } = require('child_process');
const fse  = require('fs-extra');
const path = require('path');

const GREEN  = '\x1b[32m';
const YELLOW = '\x1b[33m';
const RED    = '\x1b[31m';
const CYAN   = '\x1b[36m';
const RESET  = '\x1b[0m';
const BOLD   = '\x1b[1m';

function log(msg, color = RESET) { console.log(`${color}${msg}${RESET}`); }
function run(cmd) {
  return new Promise((resolve) => {
    exec(cmd, (err, stdout, stderr) => resolve({ ok: !err, stdout, stderr }));
  });
}

async function setup() {
  console.log('');
  log('  PluginForge AI — Setup', BOLD);
  log('  ─────────────────────────────────────', CYAN);
  console.log('');

  // Check Node.js version
  const nodeMajor = parseInt(process.version.slice(1));
  if (nodeMajor < 16) {
    log(`  Node.js v${nodeMajor} detected. Requires v16+.`, RED);
    log('  Run: pkg install nodejs', YELLOW);
    process.exit(1);
  }
  log(`  Node.js ${process.version}`, GREEN);

  // Check Maven
  const mvn = await run('mvn -version');
  if (mvn.ok) {
    const ver = mvn.stdout.split('\n')[0] || mvn.stderr.split('\n')[0] || 'found';
    log(`  Maven: ${ver.trim()}`, GREEN);
  } else {
    log('  Maven not found.', YELLOW);
    log('  To install on Termux:', YELLOW);
    log('    pkg install openjdk-21 maven', CYAN);
    log('  Build features will be unavailable until Maven is installed.', YELLOW);
  }

  // Check Java
  const java = await run('java -version');
  if (java.ok || java.stderr.includes('version')) {
    const ver = (java.stderr || java.stdout).split('\n')[0];
    log(`  Java: ${ver.trim()}`, GREEN);
  } else {
    log('  Java not found. Install with: pkg install openjdk-21', YELLOW);
  }

  // Create directories
  const dirs = ['workspace', 'tabchat', 'data', 'frontend/css', 'frontend/js'];
  for (const d of dirs) {
    await fse.ensureDir(path.join(__dirname, d));
  }
  log('  Directories created', GREEN);

  // Initialize data files
  const pPath = path.join(__dirname, 'data/projects.json');
  const sPath = path.join(__dirname, 'data/settings.json');

  if (!await fse.pathExists(pPath)) {
    await fse.writeJson(pPath, [], { spaces: 2 });
    log('  data/projects.json created', GREEN);
  } else {
    log('  data/projects.json exists', GREEN);
  }

  if (!await fse.pathExists(sPath)) {
    await fse.writeJson(sPath, {
      apiKey: '',
      defaultModel: 'kilo-auto/free',
      defaultReasoningMode: 'MEDIUM',
      defaultMcVersion: '1.21',
      defaultServerType: 'Paper',
      defaultJavaVersion: '17'
    }, { spaces: 2 });
    log('  data/settings.json created', GREEN);
  } else {
    log('  data/settings.json exists', GREEN);
  }

  console.log('');
  log('  ─────────────────────────────────────', CYAN);
  log('  PluginForge AI is ready!', BOLD);
  console.log('');
  log('  1. Run:  npm start', CYAN);
  log('  2. Open: http://localhost:3000', CYAN);
  log('  3. Set your Kilo API key in Settings', CYAN);
  console.log('');
}

setup().catch(e => {
  console.error('Setup failed:', e.message);
  process.exit(1);
});
