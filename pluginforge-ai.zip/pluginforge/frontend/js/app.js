// ── STATE
window.activeProjectId = null;

// ── BOOTSTRAP
document.addEventListener('DOMContentLoaded', async () => {
  // Init all modules
  initChat();
  initEditor();
  initContextMenu();
  initNewProject();
  initImport();
  initSettings();
  initSearch();
  initTopbarSync();
  initPanelToggles();
  initTabs();
  initDownloadButtons();
  initModalCloseHandlers();
  initShortcuts();

  // Load projects
  await loadProjects();

  // Check if API key is set
  try {
    const res = await fetch('/api/settings');
    const s   = await res.json();
    if (!s.apiKey) {
      showToast('Set your Kilo API key in Settings to get started', 'warning', 5000);
    }
  } catch {}
});
