// ── BUILD MODULE

let buildWs = null;
let lastBuildSuccess = false;

function initBuild(projectId) {
  if (buildWs) { buildWs.close(); buildWs = null; }

  const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:';
  buildWs = new WebSocket(`${protocol}//${location.host}?projectId=${projectId}`);

  buildWs.onmessage = (e) => {
    try {
      const msg = JSON.parse(e.data);
      handleBuildMsg(msg, projectId);
    } catch {}
  };

  buildWs.onerror = () => {};
  buildWs.onclose = () => {};
}

function handleBuildMsg(msg, projectId) {
  const logEl  = document.getElementById('build-log');
  const dot    = document.getElementById('build-status-dot');
  const label  = document.getElementById('build-status-text');
  const jarBtn = document.getElementById('btn-download-jar');

  if (msg.type === 'log') {
    const line = document.createElement('div');
    line.className = `log-line ${msg.level || 'info'}`;
    line.textContent = msg.line;
    logEl.appendChild(line);
    logEl.scrollTop = logEl.scrollHeight;
  }

  if (msg.type === 'success') {
    dot.className = 'status-dot online';
    label.textContent = '// build successful';
    showToast('Build succeeded!', 'success');
    jarBtn.classList.remove('disabled');
    lastBuildSuccess = true;
    document.getElementById('autofix-status').classList.add('hidden');
    loadBuildHistory(projectId);
    // Refresh files after successful build
    if (window.activeProjectId) refreshFileTree(window.activeProjectId);
  }

  if (msg.type === 'error') {
    dot.className = 'status-dot error';
    label.textContent = '// build failed';
    showToast('Build failed. Check build log.', 'error');
    lastBuildSuccess = false;
    loadBuildHistory(projectId);
  }
}

async function triggerBuild(projectId) {
  if (!projectId) return showToast('No project selected', 'warning');

  const dot   = document.getElementById('build-status-dot');
  const label = document.getElementById('build-status-text');
  const logEl = document.getElementById('build-log');

  // Switch to build tab
  document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
  document.querySelector('[data-tab="build"]').classList.add('active');
  document.getElementById('tab-build').classList.add('active');

  dot.className = 'status-dot building';
  label.textContent = '// building...';
  logEl.innerHTML = '';

  showToast('Build started', 'info');

  try {
    const res = await fetch(`/api/projects/${projectId}/build`, { method: 'POST' });
    if (!res.ok) {
      const d = await res.json();
      throw new Error(d.error || 'Build request failed');
    }
  } catch (e) {
    dot.className = 'status-dot error';
    label.textContent = '// build error';
    showToast(e.message, 'error');
  }
}

async function loadBuildHistory(projectId) {
  if (!projectId) return;
  try {
    const res  = await fetch(`/api/projects/${projectId}`);
    const proj = await res.json();
    renderBuildHistory(proj.buildHistory || [], projectId);
  } catch {}
}

function renderBuildHistory(history, projectId) {
  const container = document.getElementById('build-history');
  if (!history.length) {
    container.innerHTML = `<div style="padding:10px 12px;font-family:var(--mono);font-size:9px;color:var(--t3)">// no builds yet</div>`;
    return;
  }
  container.innerHTML = history.map(b => {
    const time = new Date(b.timestamp).toLocaleString();
    return `<div class="build-history-item" data-id="${b.id}">
      <div class="bh-dot ${b.success ? 'success' : 'fail'}"></div>
      <span class="bh-time">${time}</span>
      <span class="bh-status">${b.success ? 'OK' : 'FAIL'}</span>
    </div>`;
  }).join('');

  container.querySelectorAll('.build-history-item').forEach((item, i) => {
    item.addEventListener('click', () => {
      const build = history[i];
      const logEl = document.getElementById('build-log');
      logEl.innerHTML = (build.log || '').split('\n').map(line => {
        const level = line.includes('[ERROR]') ? 'error' : line.includes('[WARNING]') ? 'warn' : build.success ? 'info' : 'info';
        return `<div class="log-line ${level}">${escapeHtml(line)}</div>`;
      }).join('');
      logEl.scrollTop = 0;
    });
  });
}

function escapeHtml(str) {
  return (str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
