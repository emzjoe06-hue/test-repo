// ── KEYBOARD SHORTCUTS

function initShortcuts() {
  document.addEventListener('keydown', (e) => {
    const ctrl = e.ctrlKey || e.metaKey;

    // Ctrl+Enter — send (handled in chat.js, but fallback here)
    if (ctrl && e.key === 'Enter') {
      if (document.activeElement === document.getElementById('chat-input')) return;
      sendMessage();
    }

    // Ctrl+B — build
    if (ctrl && e.key === 'b') {
      e.preventDefault();
      triggerBuild(window.activeProjectId);
    }

    // Ctrl+S — export JSON
    if (ctrl && e.key === 's') {
      e.preventDefault();
      if (!window.activeProjectId) return;
      const link = document.createElement('a');
      link.href = '#';
      link.click = () => {};
      fetch(`/api/projects/${window.activeProjectId}/export`, { method: 'POST' })
        .then(res => res.blob())
        .then(blob => {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url; a.download = 'project-export.json';
          a.click(); URL.revokeObjectURL(url);
          showToast('Project exported', 'success');
        })
        .catch(e => showToast(e.message, 'error'));
    }

    // Ctrl+K — focus search
    if (ctrl && e.key === 'k') {
      e.preventDefault();
      document.getElementById('search-projects').focus();
    }

    // Ctrl+[ — collapse left panel
    if (ctrl && e.key === '[') {
      e.preventDefault();
      document.getElementById('left-panel').classList.toggle('collapsed');
    }

    // Ctrl+] — collapse right panel
    if (ctrl && e.key === ']') {
      e.preventDefault();
      document.getElementById('right-panel').classList.toggle('collapsed');
    }

    // Escape — close modals
    if (e.key === 'Escape') {
      document.querySelectorAll('.modal:not(.hidden)').forEach(m => {
        m.classList.add('hidden');
      });
      const anyOpen = document.querySelectorAll('.modal:not(.hidden)').length > 0;
      if (!anyOpen) document.getElementById('modal-overlay').classList.add('hidden');

      document.getElementById('context-menu').classList.add('hidden');
    }
  });
}
