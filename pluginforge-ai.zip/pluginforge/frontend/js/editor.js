// ── EDITOR / FILE VIEWER CONTROLS

function initEditor() {
  // Copy file
  document.getElementById('btn-copy-file').addEventListener('click', () => {
    const viewer = document.getElementById('file-viewer');
    const content = viewer.dataset.content;
    if (!content) return;
    navigator.clipboard.writeText(content).then(() => showToast('File copied to clipboard', 'success'));
  });

  // Download file
  document.getElementById('btn-download-file').addEventListener('click', () => {
    const viewer = document.getElementById('file-viewer');
    const content  = viewer.dataset.content;
    const filename = viewer.dataset.filename || 'file.txt';
    if (!content) return;
    const blob = new Blob([content], { type: 'text/plain' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = filename;
    a.click(); URL.revokeObjectURL(url);
  });

  // Close viewer
  document.getElementById('btn-close-viewer').addEventListener('click', () => {
    document.getElementById('file-viewer').classList.add('hidden');
    document.querySelectorAll('.ft-file').forEach(f => f.classList.remove('active'));
  });

  // Font size controls
  document.querySelectorAll('.font-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.font-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const viewerContent = document.getElementById('viewer-content');
      viewerContent.classList.remove('font-sm', 'font-md', 'font-lg');
      const sz = btn.dataset.size;
      if (sz === 'sm') viewerContent.classList.add('font-sm');
      if (sz === 'lg') viewerContent.classList.add('font-lg');
    });
  });
}
