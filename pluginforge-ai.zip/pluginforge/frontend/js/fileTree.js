// ── FILE TREE RENDERER

const EXT_COLORS = {
  java: '#f89820', xml: '#e34c26', yml: '#cb171e', yaml: '#cb171e',
  json: '#f1e05a', md: '#083fa1', txt: '#888888',
};

function getExt(name) { return name.split('.').pop().toLowerCase(); }

function renderFileTree(nodes, container, projectId, depth = 0) {
  nodes.forEach(node => {
    if (node.type === 'dir') {
      const folder = document.createElement('div');
      folder.className = 'ft-folder';
      folder.innerHTML = `
        <svg class="folder-closed" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
        <svg class="folder-open" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/><line x1="4" y1="10" x2="20" y2="10"/></svg>
        <span>${node.name}</span>
      `;
      const children = document.createElement('div');
      children.className = 'ft-children hidden';
      folder.addEventListener('click', (e) => {
        e.stopPropagation();
        folder.classList.toggle('open');
        children.classList.toggle('hidden');
      });
      container.appendChild(folder);
      renderFileTree(node.children || [], children, projectId, depth + 1);
      container.appendChild(children);
    } else {
      const ext = getExt(node.name);
      const file = document.createElement('div');
      file.className = 'ft-file';
      file.dataset.path = node.path;
      file.innerHTML = `
        <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V9z"/><polyline points="13,2 13,9 20,9"/></svg>
        <span>${node.name}</span>
        <span class="ft-file-ext" style="color:${EXT_COLORS[ext] || 'var(--t3)'}">.${ext}</span>
      `;
      file.addEventListener('click', () => {
        document.querySelectorAll('.ft-file').forEach(f => f.classList.remove('active'));
        file.classList.add('active');
        loadFileContent(projectId, node.path);
      });
      container.appendChild(file);
    }
  });
}

async function loadFileContent(projectId, fullPath) {
  try {
    // Extract relative path from workspace/<name>/...
    const parts = fullPath.split('/');
    const wsIdx = parts.indexOf('workspace');
    const relPath = wsIdx >= 0 ? parts.slice(wsIdx + 2).join('/') : parts.slice(-2).join('/');

    const res = await fetch(`/api/projects/${projectId}/files/content?path=${encodeURIComponent(relPath)}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);

    const viewer = document.getElementById('file-viewer');
    const fname  = document.getElementById('viewer-filename');
    const content = document.getElementById('viewer-content');

    fname.textContent = relPath;
    viewer.classList.remove('hidden');

    const ext = getExt(relPath);
    const langMap = { java: 'java', xml: 'xml', yml: 'yaml', yaml: 'yaml', json: 'json', md: 'markdown' };
    const lang = langMap[ext] || 'plaintext';

    const highlighted = hljs.highlight(data.content, { language: lang, ignoreIllegals: true }).value;
    content.innerHTML = `<pre><code class="hljs language-${lang}">${highlighted}</code></pre>`;

    // Store for download
    viewer.dataset.content  = data.content;
    viewer.dataset.filename = relPath.split('/').pop();
  } catch (e) {
    showToast(e.message, 'error');
  }
}

async function refreshFileTree(projectId) {
  if (!projectId) return;
  try {
    const res = await fetch(`/api/projects/${projectId}/files`);
    const tree = await res.json();
    const container = document.getElementById('file-tree');
    container.innerHTML = '';
    if (!tree || tree.length === 0) {
      container.innerHTML = `<div class="empty-state">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M22 19a2 2 0 01-2 2H4a2 2 0 01-2-2V5a2 2 0 012-2h5l2 3h9a2 2 0 012 2z"/></svg>
        <p>No files yet</p><small>// ask the AI to generate code</small>
      </div>`;
    } else {
      renderFileTree(tree, container, projectId);
    }
  } catch (e) {
    showToast('Failed to load file tree', 'error');
  }
}
