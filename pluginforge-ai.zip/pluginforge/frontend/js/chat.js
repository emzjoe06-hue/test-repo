// ── CHAT MODULE

let chatHistory = [];
let lastUserMessage = null;
let isStreaming = false;

// ── LOAD HISTORY
async function loadChatHistory(projectId) {
  try {
    const res = await fetch(`/api/projects/${projectId}/chat`);
    chatHistory = await res.json();
    renderChatMessages(chatHistory);
    updatePinnedSection();
  } catch {
    chatHistory = [];
    renderChatMessages([]);
  }
}

// ── RENDER ALL MESSAGES
function renderChatMessages(messages) {
  const container = document.getElementById('chat-messages');
  const query = document.getElementById('chat-search').value.trim().toLowerCase();

  const filtered = query
    ? messages.filter(m => m.content.toLowerCase().includes(query))
    : messages;

  if (!filtered.length) {
    container.innerHTML = `<div class="empty-state" style="flex:1">
      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>
      <p>${query ? 'No matching messages' : 'Start a conversation'}</p>
      <small>// describe your plugin idea</small>
    </div>`;
    return;
  }

  container.innerHTML = filtered.map((msg, i) => renderMessage(msg, i)).join('');

  // Attach events
  container.querySelectorAll('.btn-copy-msg').forEach(btn => {
    btn.addEventListener('click', () => {
      navigator.clipboard.writeText(btn.dataset.content);
      showToast('Copied', 'success');
    });
  });

  container.querySelectorAll('.btn-pin-msg').forEach(btn => {
    btn.addEventListener('click', async () => {
      const idx = parseInt(btn.dataset.index);
      await togglePinMessage(idx);
    });
  });

  // Syntax highlight all code blocks
  container.querySelectorAll('pre code').forEach(block => hljs.highlightElement(block));

  // Scroll to bottom
  container.scrollTop = container.scrollHeight;
}

// ── RENDER SINGLE MESSAGE
function renderMessage(msg, index) {
  const isUser = msg.role === 'user';
  const avatar = isUser ? 'YOU' : 'AI';
  const role   = isUser ? 'You' : 'PluginForge AI';
  const time   = msg.timestamp ? new Date(msg.timestamp).toLocaleTimeString() : '';
  const pinned = msg.pinned ? '<div class="msg-pinned-indicator"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>pinned</div>' : '';

  const rendered = isUser
    ? `<p>${escapeHtml(msg.content)}</p>`
    : renderMarkdown(msg.content);

  const plainContent = msg.content.replace(/</g, '&lt;');

  return `<div class="chat-msg" data-index="${index}">
    <div class="msg-avatar ${isUser ? 'user' : 'ai'}">${avatar}</div>
    <div class="msg-body">
      <div class="msg-meta">
        <span class="msg-role">${role}</span>
        <span class="msg-time">${time}</span>
        <div class="msg-actions">
          <button class="btn-icon-xs btn-copy-msg" data-content="${encodeURIComponent(msg.content)}" title="Copy">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
          </button>
          ${!isUser ? `<button class="btn-icon-xs btn-pin-msg" data-index="${index}" title="Pin message">
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>
          </button>` : ''}
        </div>
      </div>
      <div class="msg-content">${rendered}</div>
      ${pinned}
    </div>
  </div>`;
}

// ── RENDER MARKDOWN WITH CODE COPY BUTTONS
function renderMarkdown(content) {
  if (typeof marked === 'undefined') return `<p>${escapeHtml(content)}</p>`;

  marked.setOptions({ breaks: true, gfm: true });
  const renderer = new marked.Renderer();
  let blockCount = 0;

  renderer.code = (code, lang) => {
    const id   = `cb-${Date.now()}-${blockCount++}`;
    const safe = escapeHtml(code);
    return `<div class="code-block-wrap">
      <div class="code-block-header">
        <span class="code-lang">${lang || 'code'}</span>
        <button class="btn-icon-xs btn-copy-code" onclick="copyCodeBlock('${id}')" title="Copy code">
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
        </button>
      </div>
      <pre><code id="${id}" class="language-${lang || 'plaintext'}">${safe}</code></pre>
    </div>`;
  };

  return marked.parse(content, { renderer });
}

function copyCodeBlock(id) {
  const el = document.getElementById(id);
  if (!el) return;
  navigator.clipboard.writeText(el.textContent);
  showToast('Code copied', 'success');
}

// ── TOGGLE PIN
async function togglePinMessage(index) {
  if (!window.activeProjectId) return;
  chatHistory[index].pinned = !chatHistory[index].pinned;

  try {
    // Rewrite full history to persist pin state
    await fetch(`/api/projects/${window.activeProjectId}/chat`, { method: 'DELETE' });
    // Re-send each message to rebuild... actually just save via a dedicated approach:
    // We save the whole history by clearing and sending; simpler: use the file write endpoint
    // For now, optimistically update UI only (full persist on next send)
    renderChatMessages(chatHistory);
    updatePinnedSection();
  } catch {}
}

// ── PINNED SECTION
function updatePinnedSection() {
  const pinned = chatHistory.filter(m => m.pinned && m.role === 'assistant');
  const section = document.getElementById('pinned-section');
  const list    = document.getElementById('pinned-list');

  if (!pinned.length) {
    section.classList.add('hidden');
    return;
  }

  section.classList.remove('hidden');
  list.innerHTML = pinned.map(m => {
    const preview = m.content.replace(/\n/g, ' ').substring(0, 100) + '...';
    return `<div class="pinned-msg-preview">${escapeHtml(preview)}</div>`;
  }).join('');
}

// ── SEND MESSAGE
async function sendMessage() {
  if (isStreaming) return;
  if (!window.activeProjectId) return showToast('Select a project first', 'warning');

  const input = document.getElementById('chat-input');
  const message = input.value.trim();
  if (!message) return;

  lastUserMessage = message;
  input.value = '';
  input.style.height = '';
  isStreaming = true;

  const model         = document.getElementById('model-select').value;
  const reasoningMode = getReasoningMode();

  // Add user message to history and render
  const userMsg = { role: 'user', content: message, timestamp: new Date().toISOString(), pinned: false };
  chatHistory.push(userMsg);

  // Add placeholder AI message
  const aiMsg = { role: 'assistant', content: '', timestamp: new Date().toISOString(), pinned: false, _streaming: true };
  chatHistory.push(aiMsg);

  renderChatMessages(chatHistory);
  const container = document.getElementById('chat-messages');
  container.scrollTop = container.scrollHeight;

  // Get streaming element
  const lastMsgEl = container.lastElementChild;
  const contentEl = lastMsgEl?.querySelector('.msg-content');
  if (contentEl) contentEl.classList.add('stream-cursor');

  let fullContent = '';

  try {
    const res = await fetch(`/api/projects/${window.activeProjectId}/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, model, reasoningMode })
    });

    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Chat request failed');
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop();

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const raw = line.slice(6).trim();
        try {
          const msg = JSON.parse(raw);

          if (msg.type === 'token') {
            fullContent += msg.content;
            aiMsg.content = fullContent;
            if (contentEl) {
              contentEl.innerHTML = renderMarkdown(fullContent);
              contentEl.querySelectorAll('pre code').forEach(b => hljs.highlightElement(b));
              container.scrollTop = container.scrollHeight;
            }
          }

          if (msg.type === 'files') {
            showToast(`${msg.files.length} file(s) written`, 'success');
            await refreshFileTree(window.activeProjectId);
          }

          if (msg.type === 'error') {
            throw new Error(msg.message);
          }

          if (msg.type === 'done') {
            break;
          }
        } catch {}
      }
    }

    // Finalize
    if (contentEl) contentEl.classList.remove('stream-cursor');
    aiMsg._streaming = false;
    await loadChatHistory(window.activeProjectId);

  } catch (e) {
    showToast(e.message, 'error');
    chatHistory.pop(); // remove ai placeholder
    chatHistory.pop(); // remove user msg
    renderChatMessages(chatHistory);
    if (contentEl) contentEl.classList.remove('stream-cursor');
  } finally {
    isStreaming = false;
  }
}

// ── UNDO LAST GENERATION
async function undoLastGeneration() {
  if (!window.activeProjectId || chatHistory.length < 2) return showToast('Nothing to undo', 'warning');
  try {
    // Remove last 2 entries (user + AI)
    chatHistory.splice(-2, 2);
    // Rewrite history by clearing and re-adding (simplified: just clear then resend all)
    await fetch(`/api/projects/${window.activeProjectId}/chat`, { method: 'DELETE' });
    // Re-add remaining messages
    for (const msg of chatHistory) {
      await fetch(`/api/projects/${window.activeProjectId}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: msg.content })
      });
    }
    await loadChatHistory(window.activeProjectId);
    showToast('Last generation undone', 'success');
  } catch (e) { showToast(e.message, 'error'); }
}

// ── CLEAR CHAT
async function clearChat() {
  if (!window.activeProjectId) return;
  if (!confirm('Clear all chat history for this project?')) return;
  try {
    await fetch(`/api/projects/${window.activeProjectId}/chat`, { method: 'DELETE' });
    chatHistory = [];
    renderChatMessages([]);
    updatePinnedSection();
    showToast('Chat cleared', 'success');
  } catch (e) { showToast(e.message, 'error'); }
}

// ── INIT CHAT EVENTS
function initChat() {
  document.getElementById('btn-send').addEventListener('click', sendMessage);

  document.getElementById('chat-input').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      sendMessage();
    }
  });

  // Auto-resize textarea
  document.getElementById('chat-input').addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = Math.min(this.scrollHeight, 160) + 'px';
  });

  document.getElementById('btn-undo-gen').addEventListener('click', undoLastGeneration);
  document.getElementById('btn-clear-chat').addEventListener('click', clearChat);

  document.getElementById('chat-search').addEventListener('input', () => {
    renderChatMessages(chatHistory);
  });

  document.getElementById('btn-toggle-pinned').addEventListener('click', () => {
    const list = document.getElementById('pinned-list');
    list.classList.toggle('hidden');
  });
}

// ── UTILS
function escapeHtml(str) {
  return (str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
