// ── PROJECTS MODULE

let allProjects = [];
let contextTargetId = null;

async function loadProjects() {
  try {
    const res = await fetch('/api/projects');
    allProjects = await res.json();
    renderProjectList(allProjects);
  } catch (e) {
    showToast('Failed to load projects', 'error');
  }
}

function renderProjectList(projects) {
  const container = document.getElementById('project-list');
  const query = document.getElementById('search-projects').value.trim().toLowerCase();
  const filtered = query ? projects.filter(p => p.name.toLowerCase().includes(query) || (p.description || '').toLowerCase().includes(query)) : projects;

  if (!filtered.length) {
    container.innerHTML = `<div class="empty-state">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3 3h6v6H3zM15 3h6v6h-6zM3 15h6v6H3zM15 15h6v6h-6z"/></svg>
      <p>${query ? 'No results' : 'No plugins yet'}</p>
      <small>// ${query ? 'try a different search' : 'create your first plugin'}</small>
    </div>`;
    return;
  }

  container.innerHTML = filtered.map(p => {
    const tag = (p.tags && p.tags[0]) || 'WIP';
    const updated = timeAgo(p.updatedAt);
    return `<div class="project-item ${window.activeProjectId === p.id ? 'active' : ''}" data-id="${p.id}">
      <div class="proj-row1">
        <span class="proj-name">${escapeHtml(p.name)}</span>
        <span class="tag-badge ${tag}" data-id="${p.id}" data-tag="${tag}">${tag}</span>
      </div>
      <div class="proj-row2">
        <span class="mc-badge">${p.serverType} ${p.mcVersion}</span>
        <span class="proj-time">${updated}</span>
      </div>
    </div>`;
  }).join('');

  // Click to select project
  container.querySelectorAll('.project-item').forEach(item => {
    item.addEventListener('click', () => selectProject(item.dataset.id));
    item.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      contextTargetId = item.dataset.id;
      showContextMenu(e.clientX, e.clientY);
    });
  });

  // Tag badge click — cycle tag
  container.querySelectorAll('.tag-badge').forEach(badge => {
    badge.addEventListener('click', async (e) => {
      e.stopPropagation();
      const tags = ['WIP', 'Done', 'Broken'];
      const cur  = badge.dataset.tag;
      const next = tags[(tags.indexOf(cur) + 1) % tags.length];
      try {
        await fetch(`/api/projects/${badge.dataset.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ tags: [next] })
        });
        await loadProjects();
      } catch { showToast('Failed to update tag', 'error'); }
    });
  });
}

async function selectProject(id) {
  window.activeProjectId = id;
  const project = allProjects.find(p => p.id === id);
  if (!project) return;

  // Update UI
  document.getElementById('no-project-state').classList.add('hidden');
  document.getElementById('project-workspace').classList.remove('hidden');
  document.getElementById('active-project-name').textContent = project.name;

  // Sync topbar controls
  setSelectValue('mc-version',   project.mcVersion);
  setSelectValue('server-type',  project.serverType);
  setSelectValue('java-version', project.javaVersion);
  setSelectValue('model-select', project.model);
  setReasoningMode(project.reasoningMode);

  // Mark active in list
  document.querySelectorAll('.project-item').forEach(el => {
    el.classList.toggle('active', el.dataset.id === id);
  });

  // Init WS for build streaming
  initBuild(id);

  // Load chat history, files, build history
  await loadChatHistory(id);
  await refreshFileTree(id);
  await loadBuildHistory(id);
}

function setSelectValue(id, value) {
  const el = document.getElementById(id);
  if (!el || !value) return;
  const opt = [...el.options].find(o => o.value === value || o.text === value);
  if (opt) el.value = opt.value;
}

function setReasoningMode(mode) {
  document.querySelectorAll('.reason-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.mode === mode);
  });
}

function getReasoningMode() {
  return document.querySelector('.reason-btn.active')?.dataset.mode || 'MEDIUM';
}

// ── CONTEXT MENU
function showContextMenu(x, y) {
  const menu = document.getElementById('context-menu');
  menu.style.left = x + 'px';
  menu.style.top  = y + 'px';
  menu.classList.remove('hidden');
}

function hideContextMenu() {
  document.getElementById('context-menu').classList.add('hidden');
  contextTargetId = null;
}

function initContextMenu() {
  document.addEventListener('click', hideContextMenu);

  document.getElementById('ctx-clone').addEventListener('click', async () => {
    if (!contextTargetId) return;
    try {
      const res = await fetch(`/api/projects/${contextTargetId}/clone`, { method: 'POST' });
      if (!res.ok) throw new Error((await res.json()).error);
      await loadProjects();
      showToast('Plugin cloned', 'success');
    } catch (e) { showToast(e.message, 'error'); }
  });

  document.getElementById('ctx-export').addEventListener('click', async () => {
    if (!contextTargetId) return;
    try {
      const res = await fetch(`/api/projects/${contextTargetId}/export`, { method: 'POST' });
      if (!res.ok) throw new Error('Export failed');
      const blob = await res.blob();
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href = url; a.download = `plugin-export.json`;
      a.click(); URL.revokeObjectURL(url);
      showToast('Project exported', 'success');
    } catch (e) { showToast(e.message, 'error'); }
  });

  document.getElementById('ctx-delete').addEventListener('click', () => {
    if (!contextTargetId) return;
    const project = allProjects.find(p => p.id === contextTargetId);
    openConfirmDelete(project);
  });
}

// ── DELETE MODAL
function openConfirmDelete(project) {
  document.getElementById('confirm-delete-text').textContent =
    `Delete "${project.name}"? This will permanently remove all files and chat history.`;
  document.getElementById('modal-confirm-delete').classList.remove('hidden');
  document.getElementById('modal-overlay').classList.remove('hidden');

  document.getElementById('btn-confirm-delete').onclick = async () => {
    try {
      const res = await fetch(`/api/projects/${project.id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error((await res.json()).error);
      if (window.activeProjectId === project.id) {
        window.activeProjectId = null;
        document.getElementById('no-project-state').classList.remove('hidden');
        document.getElementById('project-workspace').classList.add('hidden');
      }
      await loadProjects();
      closeModal('modal-confirm-delete');
      showToast(`"${project.name}" deleted`, 'success');
    } catch (e) { showToast(e.message, 'error'); }
  };
}

// ── NEW PROJECT MODAL
function initNewProject() {
  document.getElementById('btn-new-project').addEventListener('click', () => {
    document.getElementById('modal-new-project').classList.remove('hidden');
    document.getElementById('modal-overlay').classList.remove('hidden');
    document.getElementById('np-name').focus();
  });

  document.getElementById('btn-create-project').addEventListener('click', async () => {
    const name = document.getElementById('np-name').value.trim();
    if (!name) return showToast('Plugin name is required', 'warning');
    if (!/^[a-zA-Z][a-zA-Z0-9_]*$/.test(name)) return showToast('Name must start with a letter and contain only letters, numbers, underscores', 'warning');

    try {
      const res = await fetch('/api/projects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          description:   document.getElementById('np-desc').value.trim(),
          mcVersion:     document.getElementById('np-mc').value,
          serverType:    document.getElementById('np-server').value,
          javaVersion:   document.getElementById('np-java').value,
          model:         document.getElementById('np-model').value,
          reasoningMode: document.getElementById('np-reasoning').value,
          tags: ['WIP']
        })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);

      closeModal('modal-new-project');
      document.getElementById('np-name').value = '';
      document.getElementById('np-desc').value = '';
      await loadProjects();
      await selectProject(data.id);
      showToast(`"${name}" created`, 'success');
    } catch (e) { showToast(e.message, 'error'); }
  });
}

// ── IMPORT
function initImport() {
  document.getElementById('btn-import').addEventListener('click', () => {
    document.getElementById('import-file-input').click();
  });

  document.getElementById('import-file-input').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      const res  = await fetch('/api/projects/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      const proj = await res.json();
      if (!res.ok) throw new Error(proj.error);
      await loadProjects();
      await selectProject(proj.id);
      showToast('Project imported', 'success');
    } catch (e) { showToast('Import failed: ' + e.message, 'error'); }
    e.target.value = '';
  });
}

// ── TOPBAR CONTROLS — sync changes back to project
function initTopbarSync() {
  ['mc-version','server-type','java-version','model-select'].forEach(id => {
    document.getElementById(id).addEventListener('change', async () => {
      if (!window.activeProjectId) return;
      const updates = {
        mcVersion:   document.getElementById('mc-version').value,
        serverType:  document.getElementById('server-type').value,
        javaVersion: document.getElementById('java-version').value,
        model:       document.getElementById('model-select').value,
      };
      try {
        await fetch(`/api/projects/${window.activeProjectId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updates)
        });
        const idx = allProjects.findIndex(p => p.id === window.activeProjectId);
        if (idx >= 0) Object.assign(allProjects[idx], updates);
      } catch {}
    });
  });

  document.querySelectorAll('.reason-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
      document.querySelectorAll('.reason-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      if (!window.activeProjectId) return;
      try {
        await fetch(`/api/projects/${window.activeProjectId}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ reasoningMode: btn.dataset.mode })
        });
      } catch {}
    });
  });
}

// ── PANEL TOGGLES
function initPanelToggles() {
  document.getElementById('btn-toggle-left').addEventListener('click', () => {
    document.getElementById('left-panel').classList.toggle('collapsed');
  });
  document.getElementById('btn-toggle-right').addEventListener('click', () => {
    document.getElementById('right-panel').classList.toggle('collapsed');
  });
}

// ── TABS (right panel)
function initTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(`tab-${btn.dataset.tab}`).classList.add('active');
    });
  });
}

// ── DOWNLOAD BUTTONS
function initDownloadButtons() {
  document.getElementById('btn-download-zip').addEventListener('click', () => {
    if (!window.activeProjectId) return;
    window.location.href = `/api/projects/${window.activeProjectId}/download/zip`;
    showToast('Downloading ZIP...', 'info');
  });

  document.getElementById('btn-build-jar').addEventListener('click', () => {
    triggerBuild(window.activeProjectId);
  });

  document.getElementById('btn-download-jar').addEventListener('click', () => {
    if (!window.activeProjectId) return;
    window.location.href = `/api/projects/${window.activeProjectId}/download/jar`;
  });
}

// ── SETTINGS MODAL
function initSettings() {
  document.getElementById('btn-settings').addEventListener('click', async () => {
    try {
      const res = await fetch('/api/settings');
      const s   = await res.json();
      document.getElementById('s-apikey').value    = s.apiKey || '';
      document.getElementById('s-model').value     = s.defaultModel || 'kilo-auto/free';
      document.getElementById('s-reasoning').value = s.defaultReasoningMode || 'MEDIUM';
      document.getElementById('s-mc').value        = s.defaultMcVersion || '1.21';
      document.getElementById('s-server').value    = s.defaultServerType || 'Paper';
    } catch {}
    document.getElementById('modal-settings').classList.remove('hidden');
    document.getElementById('modal-overlay').classList.remove('hidden');
  });

  document.getElementById('btn-save-settings').addEventListener('click', async () => {
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey:              document.getElementById('s-apikey').value.trim(),
          defaultModel:        document.getElementById('s-model').value,
          defaultReasoningMode: document.getElementById('s-reasoning').value,
          defaultMcVersion:    document.getElementById('s-mc').value,
          defaultServerType:   document.getElementById('s-server').value,
        })
      });
      if (!res.ok) throw new Error('Save failed');
      closeModal('modal-settings');
      showToast('Settings saved', 'success');
    } catch (e) { showToast(e.message, 'error'); }
  });

  document.getElementById('btn-test-api').addEventListener('click', async () => {
    const key = document.getElementById('s-apikey').value.trim();
    if (!key) return showToast('Enter an API key first', 'warning');
    showToast('Testing API key...', 'info');
    try {
      const res = await fetch('https://api.kilo.ai/api/gateway/chat/completions', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model: 'kilo-auto/free', max_tokens: 10, messages: [{ role: 'user', content: 'hi' }] })
      });
      if (res.ok) showToast('API key valid!', 'success');
      else showToast('API key invalid or quota exceeded', 'error');
    } catch { showToast('Could not reach Kilo API', 'error'); }
  });
}

// ── SEARCH FILTER
function initSearch() {
  document.getElementById('search-projects').addEventListener('input', () => {
    renderProjectList(allProjects);
  });
}

// ── MODAL CLOSE HELPERS
function closeModal(id) {
  document.getElementById(id).classList.add('hidden');
  const anyOpen = document.querySelectorAll('.modal:not(.hidden)').length > 0;
  if (!anyOpen) document.getElementById('modal-overlay').classList.add('hidden');
}

function initModalCloseHandlers() {
  document.querySelectorAll('.modal-close').forEach(btn => {
    btn.addEventListener('click', () => {
      const modalId = btn.dataset.modal;
      if (modalId) closeModal(modalId);
    });
  });

  document.getElementById('modal-overlay').addEventListener('click', (e) => {
    if (e.target === e.currentTarget) {
      document.querySelectorAll('.modal:not(.hidden)').forEach(m => closeModal(m.id));
    }
  });
}

// ── UTILS
function timeAgo(iso) {
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  const min  = Math.floor(diff / 60000);
  if (min < 1)  return 'just now';
  if (min < 60) return `${min}m ago`;
  const h = Math.floor(min / 60);
  if (h < 24)   return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

function escapeHtml(str) {
  return (str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
