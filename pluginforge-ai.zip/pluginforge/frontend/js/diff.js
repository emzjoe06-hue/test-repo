// ── DIFF VIEWER

function openDiffModal(filename, diffLines) {
  const modal = document.getElementById('modal-diff');
  const overlay = document.getElementById('modal-overlay');
  document.getElementById('diff-filename').textContent = filename;

  const content = document.getElementById('diff-content');
  content.innerHTML = diffLines.map(line => {
    const cls = line.type === 'added' ? 'added' : line.type === 'removed' ? 'removed' : '';
    const num = line.newLine || line.oldLine || '';
    const prefix = line.type === 'added' ? '+' : line.type === 'removed' ? '-' : ' ';
    const escaped = escapeHtml(line.content);
    return `<div class="diff-line ${cls}">
      <span class="diff-line-num">${num}</span>
      <span class="diff-line-content">${prefix} ${escaped}</span>
    </div>`;
  }).join('');

  modal.classList.remove('hidden');
  overlay.classList.remove('hidden');
}

function escapeHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
