// ── DIFF MANAGER
// Returns a unified-style diff array for display in the frontend diff viewer.

function computeDiff(oldText, newText) {
  const oldLines = (oldText || '').split('\n');
  const newLines = (newText || '').split('\n');

  // Simple LCS-based diff
  const result = [];
  let oi = 0, ni = 0;

  // Build LCS table
  const m = oldLines.length, n = newLines.length;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = m - 1; i >= 0; i--) {
    for (let j = n - 1; j >= 0; j--) {
      dp[i][j] = oldLines[i] === newLines[j]
        ? dp[i+1][j+1] + 1
        : Math.max(dp[i+1][j], dp[i][j+1]);
    }
  }

  oi = 0; ni = 0;
  while (oi < m || ni < n) {
    if (oi < m && ni < n && oldLines[oi] === newLines[ni]) {
      result.push({ type: 'unchanged', content: oldLines[oi], oldLine: oi + 1, newLine: ni + 1 });
      oi++; ni++;
    } else if (ni < n && (oi >= m || dp[oi][ni+1] >= dp[oi+1][ni])) {
      result.push({ type: 'added', content: newLines[ni], newLine: ni + 1 });
      ni++;
    } else {
      result.push({ type: 'removed', content: oldLines[oi], oldLine: oi + 1 });
      oi++;
    }
  }

  return result;
}

module.exports = { computeDiff };
