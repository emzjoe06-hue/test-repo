const fse  = require('fs-extra');
const path = require('path');

// ── PARSE FILE BLOCKS FROM AI RESPONSE
function parseFilesFromAIResponse(text) {
  const files  = [];
  // Match: FILE: <path>\n```<lang?>\n<content>\n```
  const regex  = /FILE:\s*([\w.\/\-]+)\n```[\w]*\n([\s\S]*?)```/g;
  let match;
  while ((match = regex.exec(text)) !== null) {
    files.push({ path: match[1].trim(), content: match[2] });
  }
  return files;
}

// ── WRITE PARSED FILES TO DISK
async function writeProjectFiles(files) {
  for (const f of files) {
    await fse.ensureDir(path.dirname(f.path));
    await fse.writeFile(f.path, f.content, 'utf8');
  }
}

// ── BUILD NESTED TREE STRUCTURE
async function getFileTree(projectPath) {
  async function walk(dir) {
    const entries = await fse.readdir(dir, { withFileTypes: true });
    const nodes   = [];
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) {
        nodes.push({ name: e.name, type: 'dir', children: await walk(full), path: full });
      } else {
        nodes.push({ name: e.name, type: 'file', path: full });
      }
    }
    return nodes.sort((a, b) => {
      if (a.type !== b.type) return a.type === 'dir' ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
  }
  return walk(projectPath);
}

// ── SIMPLE LINE DIFF
function getFileDiff(oldContent, newContent) {
  const oldLines = (oldContent || '').split('\n');
  const newLines = (newContent || '').split('\n');
  const result   = { added: [], removed: [], unchanged: [] };

  const oldSet = new Set(oldLines);
  const newSet = new Set(newLines);

  newLines.forEach((l, i) => {
    if (!oldSet.has(l)) result.added.push({ line: i + 1, content: l });
    else result.unchanged.push({ line: i + 1, content: l });
  });
  oldLines.forEach((l, i) => {
    if (!newSet.has(l)) result.removed.push({ line: i + 1, content: l });
  });

  return result;
}

module.exports = { parseFilesFromAIResponse, writeProjectFiles, getFileTree, getFileDiff };
