const fse  = require('fs-extra');
const path = require('path');

const PROJECT_ROOT = path.join(__dirname, '../../');

// ── PARSE FILE BLOCKS FROM AI RESPONSE
// Handles all real-world variations the AI produces:
//   FILE: workspace/PluginName/src/...
//   FILE: workspace/PluginName/pom.xml
//   followed by ```java, ```xml, ```yaml, ```  (any or no lang tag)
function parseFilesFromAIResponse(text) {
  const files = [];

  // Match FILE: <path> then optional whitespace/newline then ```[lang]\n<content>\n```
  // The path may contain: letters, digits, . / \ - _ (covers all Maven paths)
  const regex = /FILE:\s*([^\n`]+?)\s*\n\s*```[a-zA-Z0-9]*\n([\s\S]*?)```/g;

  let match;
  while ((match = regex.exec(text)) !== null) {
    const filePath = match[1].trim();
    const content  = match[2]; // preserve exact content including trailing newline

    if (!filePath) continue;

    files.push({ path: filePath, content });
  }

  return files;
}

// ── WRITE PARSED FILES TO DISK
// Paths from the AI look like: workspace/PluginName/src/main/java/...
// We resolve them relative to the project root so they land in the right place.
async function writeProjectFiles(files) {
  const written = [];
  for (const f of files) {
    try {
      // Normalise: strip leading slash or ./
      const rel  = f.path.replace(/^\.?\//, '');
      const full = path.resolve(PROJECT_ROOT, rel);

      // Safety: must stay inside project root
      if (!full.startsWith(path.resolve(PROJECT_ROOT))) {
        continue;
      }

      await fse.ensureDir(path.dirname(full));
      await fse.writeFile(full, f.content, 'utf8');
      written.push({ path: f.path, full });
    } catch (e) {
      // Log but don't abort — write as many files as possible
      console.error(`Failed to write ${f.path}: ${e.message}`);
    }
  }
  return written;
}

// ── BUILD NESTED TREE STRUCTURE
async function getFileTree(projectPath) {
  async function walk(dir) {
    let entries;
    try {
      entries = await fse.readdir(dir, { withFileTypes: true });
    } catch {
      return [];
    }
    const nodes = [];
    for (const e of entries) {
      // Skip Maven build output and hidden dirs
      if (['target', '.git', 'node_modules'].includes(e.name)) continue;
      const full = path.join(dir, e.name);
      if (e.isDirectory()) {
        nodes.push({ name: e.name, type: 'dir', children: await walk(full), path: full });
      } else {
        nodes.push({ name: e.name, type: 'file', path: full });
      }
    }
    return nodes.sort((a, b) => {
      if (a.type !== b.type) return a.type === 'dir' ? -1 : 1;
      return a.name.localeCompare(b.name);
    });
  }
  return walk(projectPath);
}

// ── SIMPLE LINE DIFF
function getFileDiff(oldContent, newContent) {
  const oldLines = (oldContent || '').split('\n');
  const newLines = (newContent || '').split('\n');
  const result   = { added: [], removed: [], unchanged: [] };

  const oldSet = new Set(oldLines);
  const newSet = new Set(newLines);

  newLines.forEach((l, i) => {
    if (!oldSet.has(l)) result.added.push({ line: i + 1, content: l });
    else result.unchanged.push({ line: i + 1, content: l });
  });
  oldLines.forEach((l, i) => {
    if (!newSet.has(l)) result.removed.push({ line: i + 1, content: l });
  });

  return result;
}

module.exports = { parseFilesFromAIResponse, writeProjectFiles, getFileTree, getFileDiff };
