const { exec, spawn } = require('child_process');
const path = require('path');
const fse  = require('fs-extra');

// ── CHECK MAVEN
function checkMavenInstalled() {
  return new Promise(resolve => {
    exec('mvn -version', (err) => resolve(!err));
  });
}

// ── INSTALL MAVEN (Termux)
function installMaven() {
  return new Promise((resolve, reject) => {
    const proc = spawn('pkg', ['install', '-y', 'openjdk-21', 'maven'], { stdio: 'pipe' });
    proc.on('close', code => code === 0 ? resolve() : reject(new Error('Maven install failed')));
  });
}

// ── BUILD PROJECT — streams lines to WebSocket clients
function buildProject(projectName, wsSet) {
  return new Promise((resolve, reject) => {
    const pomPath = path.join(__dirname, '../../workspace', projectName, 'pom.xml');

    function send(msg) {
      if (!wsSet || wsSet.size === 0) return;
      const str = JSON.stringify(msg);
      wsSet.forEach(ws => { try { ws.send(str); } catch {} });
    }

    const proc = spawn('mvn', ['clean', 'package', '-f', pomPath], {
      stdio: ['ignore', 'pipe', 'pipe']
    });

    let fullLog = '';

    proc.stdout.on('data', chunk => {
      const lines = chunk.toString().split('\n').filter(Boolean);
      lines.forEach(line => {
        fullLog += line + '\n';
        const level = line.includes('[ERROR]') ? 'error'
                    : line.includes('[WARNING]') ? 'warn'
                    : 'info';
        send({ type: 'log', line, level });
      });
    });

    proc.stderr.on('data', chunk => {
      const lines = chunk.toString().split('\n').filter(Boolean);
      lines.forEach(line => {
        fullLog += line + '\n';
        send({ type: 'log', line, level: 'error' });
      });
    });

    proc.on('close', async code => {
      if (code === 0) {
        const jarPath = await getJarPath(projectName);
        send({ type: 'success', jarPath });
        resolve({ success: true, log: fullLog, jarPath });
      } else {
        send({ type: 'error', log: fullLog });
        resolve({ success: false, log: fullLog, jarPath: null });
      }
    });

    proc.on('error', err => {
      send({ type: 'error', log: err.message });
      resolve({ success: false, log: err.message, jarPath: null });
    });
  });
}

// ── FIND COMPILED JAR
async function getJarPath(projectName) {
  const targetDir = path.join(__dirname, '../../workspace', projectName, 'target');
  try {
    const files = await fse.readdir(targetDir);
    const jar   = files.find(f => f.endsWith('.jar') && !f.includes('original'));
    return jar ? path.join(targetDir, jar) : null;
  } catch {
    return null;
  }
}

module.exports = { checkMavenInstalled, installMaven, buildProject, getJarPath };
