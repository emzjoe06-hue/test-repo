require('dotenv').config();
const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const path = require('path');
const fse = require('fs-extra');

const projectsRouter = require('./routes/projects');
const filesRouter    = require('./routes/files');
const buildRouter    = require('./routes/build');
const chatRouter     = require('./routes/chat');

const app    = express();
const server = http.createServer(app);
const wss    = new WebSocket.Server({ server });

// ── GLOBAL WS MAP: projectId → Set<WebSocket>
const wsClients = new Map();
app.locals.wsClients = wsClients;
app.locals.wss       = wss;

wss.on('connection', (ws, req) => {
  const params   = new URL(req.url, 'http://localhost').searchParams;
  const projectId = params.get('projectId');
  if (!projectId) { ws.close(); return; }
  if (!wsClients.has(projectId)) wsClients.set(projectId, new Set());
  wsClients.get(projectId).add(ws);
  ws.on('close', () => wsClients.get(projectId)?.delete(ws));
});

// ── MIDDLEWARE
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, '../frontend')));

// ── ROUTES
app.use('/api/projects', projectsRouter);
app.use('/api/projects', filesRouter);
app.use('/api/projects', buildRouter);
app.use('/api/projects', chatRouter);

// ── TEST API KEY PROXY (avoids browser CORS)
const https = require('https');

app.post('/api/test-key', (req, res) => {
  const { apiKey } = req.body;
  if (!apiKey) return res.status(400).json({ error: 'No key provided' });

  const payload = JSON.stringify({
    model: 'kilo-auto/free',
    max_tokens: 10,
    messages: [{ role: 'user', content: 'hi' }]
  });

  const options = {
    hostname: 'api.kilo.ai',
    path: '/api/gateway/chat/completions',
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(payload)
    }
  };

  const apiReq = https.request(options, (apiRes) => {
    apiRes.resume();
    if (apiRes.statusCode < 400) {
      res.json({ ok: true });
    } else {
      res.status(400).json({ error: `Kilo returned ${apiRes.statusCode}` });
    }
  });
  apiReq.on('error', (e) => res.status(500).json({ error: e.message }));
  apiReq.write(payload);
  apiReq.end();
});

// ── SETTINGS ROUTES (inline, minimal)
const SETTINGS_PATH = path.join(__dirname, '../data/settings.json');

app.get('/api/settings', async (_req, res) => {
  try {
    const s = await fse.readJson(SETTINGS_PATH);
    res.json(s);
  } catch { res.json({}); }
});

app.put('/api/settings', async (req, res) => {
  try {
    const current = await fse.readJson(SETTINGS_PATH).catch(() => ({}));
    const updated  = { ...current, ...req.body };
    await fse.writeJson(SETTINGS_PATH, updated, { spaces: 2 });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── STARTUP INIT
async function init() {
  const dirs = [
    path.join(__dirname, '../workspace'),
    path.join(__dirname, '../tabchat'),
    path.join(__dirname, '../data'),
  ];
  for (const d of dirs) await fse.ensureDir(d);

  const pPath = path.join(__dirname, '../data/projects.json');
  const sPath = path.join(__dirname, '../data/settings.json');
  if (!await fse.pathExists(pPath)) await fse.writeJson(pPath, [], { spaces: 2 });
  if (!await fse.pathExists(sPath)) {
    await fse.writeJson(sPath, {
      apiKey: '',
      defaultModel: 'kilo-auto/free',
      defaultReasoningMode: 'MEDIUM',
      defaultMcVersion: '1.21',
      defaultServerType: 'Paper',
      defaultJavaVersion: '17'
    }, { spaces: 2 });
  }

  const PORT = process.env.PORT || 3000;
  server.listen(PORT, () => {
    console.log(`PluginForge AI running on http://localhost:${PORT}`);
  });
}

init();
