const fse  = require('fs-extra');
const path = require('path');

const SETTINGS_PATH = path.join(__dirname, '../../data/settings.json');

// ── REQUIRE API KEY CONFIGURED
async function requireApiKey(req, res, next) {
  try {
    const settings = await fse.readJson(SETTINGS_PATH).catch(() => ({}));
    if (!settings.apiKey) {
      return res.status(401).json({ error: 'API key not configured. Set it in Settings.' });
    }
    req.apiKey = settings.apiKey;
    next();
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
}

module.exports = { requireApiKey };
