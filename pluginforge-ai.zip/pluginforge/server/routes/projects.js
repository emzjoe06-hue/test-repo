const express = require('express');
const router  = express.Router();
const fse     = require('fs-extra');
const path    = require('path');
const { v4: uuidv4 } = require('uuid');

const PROJECTS_PATH = path.join(__dirname, '../../data/projects.json');
const WORKSPACE     = path.join(__dirname, '../../workspace');
const TABCHAT       = path.join(__dirname, '../../tabchat');

// ── HELPERS
async function readProjects() {
  return fse.readJson(PROJECTS_PATH).catch(() => []);
}
async function writeProjects(data) {
  await fse.writeJson(PROJECTS_PATH, data, { spaces: 2 });
}

// ── LIST PROJECTS
router.get('/', async (_req, res) => {
  const projects = await readProjects();
  res.json(projects);
});

// ── CREATE PROJECT
router.post('/', async (req, res) => {
  try {
    const { name, description, tags, model, reasoningMode, mcVersion, serverType, javaVersion } = req.body;
    if (!name) return res.status(400).json({ error: 'Name is required' });

    const projects = await readProjects();
    if (projects.find(p => p.name === name)) {
      return res.status(409).json({ error: 'Project name already exists' });
    }

    const project = {
      id: uuidv4(),
      name,
      description: description || '',
      tags: tags || ['WIP'],
      model: model || 'kilo-auto/free',
      reasoningMode: reasoningMode || 'MEDIUM',
      mcVersion: mcVersion || '1.21',
      serverType: serverType || 'Paper',
      javaVersion: javaVersion || '17',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      buildHistory: []
    };

    // Create workspace + tabchat dirs
    await fse.ensureDir(path.join(WORKSPACE, name, 'src/main/java/com/pluginforge', name.toLowerCase()));
    await fse.ensureDir(path.join(WORKSPACE, name, 'src/main/resources'));
    await fse.ensureDir(path.join(TABCHAT, name));
    await fse.writeJson(path.join(TABCHAT, name, 'history.json'), [], { spaces: 2 });

    projects.push(project);
    await writeProjects(projects);
    res.json(project);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── GET PROJECT
router.get('/:id', async (req, res) => {
  const projects = await readProjects();
  const project  = projects.find(p => p.id === req.params.id);
  if (!project) return res.status(404).json({ error: 'Not found' });
  res.json(project);
});

// ── UPDATE PROJECT
router.put('/:id', async (req, res) => {
  try {
    const projects = await readProjects();
    const idx      = projects.findIndex(p => p.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Not found' });

    projects[idx] = { ...projects[idx], ...req.body, id: projects[idx].id, updatedAt: new Date().toISOString() };
    await writeProjects(projects);
    res.json(projects[idx]);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── DELETE PROJECT
router.delete('/:id', async (req, res) => {
  try {
    const projects = await readProjects();
    const project  = projects.find(p => p.id === req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });

    await fse.remove(path.join(WORKSPACE, project.name));
    await fse.remove(path.join(TABCHAT, project.name));

    const updated = projects.filter(p => p.id !== req.params.id);
    await writeProjects(updated);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── CLONE PROJECT
router.post('/:id/clone', async (req, res) => {
  try {
    const projects = await readProjects();
    const source   = projects.find(p => p.id === req.params.id);
    if (!source) return res.status(404).json({ error: 'Not found' });

    const newName = `${source.name}_copy_${Date.now()}`;
    const clone   = {
      ...source,
      id: uuidv4(),
      name: newName,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      buildHistory: []
    };

    await fse.copy(path.join(WORKSPACE, source.name), path.join(WORKSPACE, newName));
    await fse.ensureDir(path.join(TABCHAT, newName));
    await fse.writeJson(path.join(TABCHAT, newName, 'history.json'), [], { spaces: 2 });

    projects.push(clone);
    await writeProjects(projects);
    res.json(clone);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── EXPORT PROJECT AS JSON
router.post('/:id/export', async (req, res) => {
  try {
    const projects = await readProjects();
    const project  = projects.find(p => p.id === req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });

    const history  = await fse.readJson(path.join(TABCHAT, project.name, 'history.json')).catch(() => []);
    const files    = {};
    const workDir  = path.join(WORKSPACE, project.name);

    async function collectFiles(dir) {
      const entries = await fse.readdir(dir, { withFileTypes: true });
      for (const e of entries) {
        const full = path.join(dir, e.name);
        if (e.isDirectory()) await collectFiles(full);
        else files[path.relative(workDir, full)] = await fse.readFile(full, 'utf8');
      }
    }
    if (await fse.pathExists(workDir)) await collectFiles(workDir);

    res.setHeader('Content-Disposition', `attachment; filename="${project.name}.pluginforge.json"`);
    res.json({ project, history, files });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── IMPORT PROJECT FROM JSON
router.post('/import', async (req, res) => {
  try {
    const { project, history, files } = req.body;
    if (!project || !project.name) return res.status(400).json({ error: 'Invalid import data' });

    const projects = await readProjects();
    const newProject = { ...project, id: uuidv4(), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };

    const workDir = path.join(WORKSPACE, newProject.name);
    await fse.ensureDir(workDir);
    for (const [rel, content] of Object.entries(files || {})) {
      const full = path.join(workDir, rel);
      await fse.ensureDir(path.dirname(full));
      await fse.writeFile(full, content, 'utf8');
    }

    await fse.ensureDir(path.join(TABCHAT, newProject.name));
    await fse.writeJson(path.join(TABCHAT, newProject.name, 'history.json'), history || [], { spaces: 2 });

    projects.push(newProject);
    await writeProjects(projects);
    res.json(newProject);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
