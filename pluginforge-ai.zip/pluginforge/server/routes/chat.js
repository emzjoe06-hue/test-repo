const express = require('express');
const router  = express.Router();
const fse     = require('fs-extra');
const path    = require('path');
const https   = require('https');
const http    = require('http');
const { parseFilesFromAIResponse, writeProjectFiles } = require('../utils/fileManager');

const PROJECTS = path.join(__dirname, '../../data/projects.json');
const SETTINGS = path.join(__dirname, '../../data/settings.json');
const TABCHAT  = path.join(__dirname, '../../tabchat');

async function readProjects() { return fse.readJson(PROJECTS).catch(() => []); }
async function getSettings()  { return fse.readJson(SETTINGS).catch(() => ({})); }

// ── SYSTEM PROMPT TEMPLATE
const SYSTEM_PROMPT = `You are PluginForge AI, an expert Minecraft Java plugin developer with 10+ years of experience. You are working on the plugin: {pluginName} targeting {serverType} {mcVersion} with Java {javaVersion}.

WORKSPACE RULE: All files belong to workspace/{pluginName}/. Never mix code or context between different plugins.

FILE OUTPUT FORMAT — CRITICAL:
Every file you generate MUST be prefixed exactly like this:
FILE: workspace/{pluginName}/path/to/File.java
\`\`\`java
// full file content here
\`\`\`
Always output complete files. Never truncate. Never say "same as before."

IDEA EXPANSION PHASE:
When given a plugin idea, NEVER immediately generate code. First respond with:

1. COMPLEXITY: Rate as Easy | Medium | Hard | Very Hard + brief reason
2. SUGGESTED FEATURES: List 6-12 features grouped by category. Each labeled [Core] [Optional] or [Advanced] with a one-line description
3. DEPENDENCIES: List external plugins that would help (Vault, WorldGuard, PlaceholderAPI etc) and why
4. API COMPATIBILITY: Warn about anything that does not exist in {mcVersion}
5. PERMISSIONS: Suggest clean permission node structure
6. COMMANDS: Suggest command layout with aliases and subcommands
7. CONFIG PREVIEW: Show what config.yml will look like

Then ask: "Ready to generate? Tell me what to add, remove, or change."

GENERATION PHASE:
When user approves, output ALL files in this order:
1. pom.xml
2. plugin.yml
3. config.yml (fully commented)
4. Main.java
5. All manager classes
6. All listener classes
7. All command classes
8. Utility classes
9. README.md

CODING STANDARDS:
- Java {javaVersion}, prefer {serverType} API
- Never block the main thread — use BukkitRunnable.runAsync for heavy tasks
- Use UUID for player storage, never player names
- Null checks everywhere relevant
- Save all data on onDisable()
- Register commands in BOTH plugin.yml AND code
- Never use deprecated methods without a comment explaining why
- Use try-catch for all I/O operations
- Close all resources (DB connections, streams)

ANTI-PATTERN DETECTION:
After generating, check and report any of these found:
[!] Blocking main thread
[!] Storing Player objects instead of UUIDs
[!] Tasks not cancelled on onDisable
[!] Memory leaks from unclosed resources
[!] Hardcoded values that should be in config.yml
[!] Missing permission checks on commands

BUILD ERROR HANDLING:
When user pastes a build error:
1. Identify exact file and line
2. Explain the error in plain English
3. Output ONLY the fixed files in full
4. Explain what changed and why

ITERATION:
When updating code based on user requests:
- Only regenerate changed files
- Label what changed: "Updated: Main.java, ArenaManager.java"
- Brief summary of what was added/changed/removed

REASONING MODE: {reasoningMode}
STRICT — double-check everything, verify all imports, thread safety, null checks, plugin.yml accuracy. Self-review and list potential issues. Be verbose.
MEDIUM — check for obvious errors, ensure plugin.yml is complete, briefly explain key decisions.
LOW — generate fast, minimal checking, only flag critical blockers.

ALWAYS end every single response with:
SUGGESTIONS:
[3-5 specific features or improvements to add next]`;

function fillPrompt(template, vars) {
  return template.replace(/\{(\w+)\}/g, (_, k) => vars[k] || k);
}

// ── GET CHAT HISTORY
router.get('/:id/chat', async (req, res) => {
  try {
    const projects = await readProjects();
    const project  = projects.find(p => p.id === req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });
    const history = await fse.readJson(path.join(TABCHAT, project.name, 'history.json')).catch(() => []);
    res.json(history);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── SEND MESSAGE — SSE streaming
router.post('/:id/chat', async (req, res) => {
  try {
    const projects = await readProjects();
    const project  = projects.find(p => p.id === req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });

    const settings = await getSettings();
    if (!settings.apiKey) return res.status(401).json({ error: 'API key not configured' });

    const { message, model, reasoningMode } = req.body;
    const histPath = path.join(TABCHAT, project.name, 'history.json');
    const history  = await fse.readJson(histPath).catch(() => []);

    const systemPrompt = fillPrompt(SYSTEM_PROMPT, {
      pluginName:    project.name,
      serverType:    project.serverType,
      mcVersion:     project.mcVersion,
      javaVersion:   project.javaVersion,
      reasoningMode: reasoningMode || project.reasoningMode
    });

    const messages = [
      ...history.map(h => ({ role: h.role, content: h.content })),
      { role: 'user', content: message }
    ];

    const body = {
      model: model || project.model || 'kilo-auto/free',
      stream: true,
      max_tokens: 16000,
      messages
    };

    if ((model || project.model || '').includes('thinking')) {
      body.thinking = { budget_tokens: 8000 };
    }

    // ── SSE headers
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.flushHeaders();

    const send = (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);

    // ── Call Kilo API
    const apiUrl = new URL('https://api.kilo.ai/api/gateway/chat/completions');
    const reqOptions = {
      hostname: apiUrl.hostname,
      path: apiUrl.pathname,
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${settings.apiKey}`,
        'Content-Type': 'application/json'
      }
    };

    let fullResponse = '';
    const transport = apiUrl.protocol === 'https:' ? https : http;

    const apiReq = transport.request(reqOptions, (apiRes) => {
      apiRes.on('data', chunk => {
        const lines = chunk.toString().split('\n').filter(l => l.startsWith('data: '));
        for (const line of lines) {
          const raw = line.slice(6).trim();
          if (raw === '[DONE]') { send({ type: 'done' }); return; }
          try {
            const parsed = JSON.parse(raw);
            const delta  = parsed.choices?.[0]?.delta?.content || '';
            if (delta) {
              fullResponse += delta;
              send({ type: 'token', content: delta });
            }
          } catch {}
        }
      });

      apiRes.on('end', async () => {
        try {
          // Parse and write files
          const detectedFiles = parseFilesFromAIResponse(fullResponse);
          if (detectedFiles.length > 0) {
            await writeProjectFiles(detectedFiles);
            send({ type: 'files', files: detectedFiles.map(f => f.path) });
          }

          // Save history
          const newHistory = [
            ...history,
            { role: 'user', content: message, timestamp: new Date().toISOString(), pinned: false },
            { role: 'assistant', content: fullResponse, timestamp: new Date().toISOString(), pinned: false }
          ];
          await fse.writeJson(histPath, newHistory, { spaces: 2 });

          send({ type: 'done' });
          res.end();
        } catch (e) {
          send({ type: 'error', message: e.message });
          res.end();
        }
      });
    });

    apiReq.on('error', (e) => {
      send({ type: 'error', message: e.message });
      res.end();
    });

    apiReq.write(JSON.stringify({ ...body, system: systemPrompt }));
    apiReq.end();

  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── CLEAR CHAT HISTORY
router.delete('/:id/chat', async (req, res) => {
  try {
    const projects = await readProjects();
    const project  = projects.find(p => p.id === req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });
    await fse.writeJson(path.join(TABCHAT, project.name, 'history.json'), [], { spaces: 2 });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
