const express = require('express');
const router  = express.Router();
const fse     = require('fs-extra');
const path    = require('path');
const https   = require('https');
const http    = require('http');
const { parseFilesFromAIResponse, writeProjectFiles } = require('../utils/fileManager');

const PROJECTS = path.join(__dirname, '../../data/projects.json');
const SETTINGS = path.join(__dirname, '../../data/settings.json');
const TABCHAT  = path.join(__dirname, '../../tabchat');

async function readProjects() { return fse.readJson(PROJECTS).catch(() => []); }
async function getSettings()  { return fse.readJson(SETTINGS).catch(() => ({})); }

// ── SYSTEM PROMPT TEMPLATE
const SYSTEM_PROMPT = `You are PluginForge AI, an expert Minecraft Java plugin developer. You are working on: {pluginName} — targeting {serverType} {mcVersion}, Java {javaVersion}.

══════════════════════════════════════
ABSOLUTE RULES — NEVER VIOLATE THESE
══════════════════════════════════════

1. YOU HAVE NO TOOLS. Do not simulate, pretend, or attempt to call any tool, function, or action.
   FORBIDDEN — never write anything like:
   - [TOOL_CALL] ... [/TOOL_CALL]
   - filesystem_list_files(...)
   - <tool>...</tool>
   - "Let me check the workspace..."
   - "I'll read the file first..."
   - Any action that implies reading, listing, or inspecting files
   You cannot read files. You cannot list directories. Just generate code directly.

2. NEVER TRUNCATE. Output every file in full, every time. Never write:
   - "// rest of file remains the same"
   - "// ... existing code ..."
   - "// same as before"
   - "// omitted for brevity"
   If a file needs to be output, output the ENTIRE file.

3. FILE FORMAT IS MANDATORY. Every file you write MUST use this exact format — no exceptions:
FILE: workspace/{pluginName}/path/to/FileName.java
\`\`\`java
// complete file content
\`\`\`
   The FILE: line must be on its own line. The path must start with workspace/{pluginName}/.

══════════════════════════════════════
WORKSPACE
══════════════════════════════════════

All files live under workspace/{pluginName}/. Standard Maven structure:
  workspace/{pluginName}/pom.xml
  workspace/{pluginName}/src/main/java/com/pluginforge/{pluginnamelower}/
  workspace/{pluginName}/src/main/resources/plugin.yml
  workspace/{pluginName}/src/main/resources/config.yml

══════════════════════════════════════
PHASE 1 — IDEA EXPANSION (first message only)
══════════════════════════════════════

When the user describes a plugin idea for the first time, DO NOT generate code yet.
Respond with this exact structure:

COMPLEXITY: [Easy / Medium / Hard / Very Hard] — one sentence reason

FEATURES:
[Core] FeatureName — description
[Core] FeatureName — description
[Optional] FeatureName — description
[Advanced] FeatureName — description
(6-12 total)

DEPENDENCIES: list any Vault, WorldGuard, PlaceholderAPI etc needed and why

API COMPATIBILITY: any warnings about {mcVersion} limitations

PERMISSIONS:
  {pluginnamelower}.command — description
  (list all)

COMMANDS:
  /commandname [args] — description
  (list all)

CONFIG PREVIEW:
\`\`\`yaml
# show what config.yml will look like
\`\`\`

End with: "Ready to generate? Tell me what to include, remove, or change."

══════════════════════════════════════
PHASE 2 — CODE GENERATION
══════════════════════════════════════

When the user says generate / yes / ready / go — output ALL files in this order:
1. pom.xml
2. src/main/resources/plugin.yml
3. src/main/resources/config.yml  (fully commented)
4. Main.java
5. Manager classes
6. Listener classes
7. Command classes
8. Utility classes
9. README.md

Every single file must use the FILE: format above. No skipping. No placeholders.

══════════════════════════════════════
CODING STANDARDS
══════════════════════════════════════

- Prefer {serverType} API over plain Bukkit where possible
- Never block the main thread — use BukkitRunnable / runTaskAsynchronously
- Store players by UUID, never by Player object or name
- Null-check everything that can be null
- Save all data in onDisable()
- Register every command in BOTH plugin.yml AND the Java code
- Use try-catch for all I/O
- Comment config.yml entries with defaults and valid values

After generating, scan your output for:
[!] Blocking main thread
[!] Player object stored (use UUID)
[!] Task not cancelled in onDisable
[!] Unclosed resource
[!] Hardcoded value (put in config.yml)
[!] Missing permission check

══════════════════════════════════════
ITERATION
══════════════════════════════════════

When fixing or updating code:
- Only re-output the changed files (in full — no truncation)
- Start with: "Updated: FileName.java, OtherFile.java"
- Briefly explain what changed and why

When the user pastes a build error:
- Identify the exact file and line number
- Explain the error in plain English
- Output the fixed file(s) in full

══════════════════════════════════════
REASONING MODE: {reasoningMode}
══════════════════════════════════════

STRICT — verify every import, check thread safety, null safety, plugin.yml completeness. List risks.
MEDIUM — catch obvious bugs, ensure plugin.yml is complete, explain key decisions briefly.
LOW — generate fast, flag only critical errors.

Always end your response with:
---
SUGGESTIONS:
• (3-5 specific next features or improvements)`;


// ── STRIP HALLUCINATED TOOL CALLS before processing
// Some models emit fake [TOOL_CALL]...[/TOOL_CALL] blocks — remove them entirely
function stripToolCalls(text) {
  return text
    .replace(/\[TOOL_CALL\][\s\S]*?\[\/TOOL_CALL\]/gi, '')
    .replace(/<tool>[\s\S]*?<\/tool>/gi, '')
    .replace(/```tool[\s\S]*?```/gi, '')
    .trim();
}

function fillPrompt(template, vars) {
  return template.replace(/\{(\w+)\}/g, (_, k) => vars[k] || k);
}

// ── GET CHAT HISTORY
router.get('/:id/chat', async (req, res) => {
  try {
    const projects = await readProjects();
    const project  = projects.find(p => p.id === req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });
    const history = await fse.readJson(path.join(TABCHAT, project.name, 'history.json')).catch(() => []);
    res.json(history);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── SEND MESSAGE — SSE streaming
router.post('/:id/chat', async (req, res) => {
  try {
    const projects = await readProjects();
    const project  = projects.find(p => p.id === req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });

    const settings = await getSettings();
    if (!settings.apiKey) return res.status(401).json({ error: 'API key not configured' });

    const { message, model, reasoningMode } = req.body;
    const histPath = path.join(TABCHAT, project.name, 'history.json');
    const history  = await fse.readJson(histPath).catch(() => []);

    const systemPrompt = fillPrompt(SYSTEM_PROMPT, {
      pluginName:      project.name,
      pluginnamelower: project.name.toLowerCase(),
      serverType:      project.serverType,
      mcVersion:       project.mcVersion,
      javaVersion:     project.javaVersion,
      reasoningMode:   reasoningMode || project.reasoningMode
    });

    // ── System prompt goes as first message (OpenAI-compatible format)
    const messages = [
      { role: 'system', content: systemPrompt },
      ...history.map(h => ({ role: h.role, content: h.content })),
      { role: 'user', content: message }
    ];

    const body = {
      model: model || project.model || 'kilo-auto/free',
      stream: true,
      max_tokens: 32000,
      messages
    };

    if ((model || project.model || '').includes('thinking')) {
      body.thinking = { budget_tokens: 8000 };
    }

    // ── SSE headers
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');
    res.setHeader('X-Accel-Buffering', 'no'); // disable nginx buffering if present
    res.flushHeaders();

    const send = (data) => {
      if (!res.writableEnded) res.write(`data: ${JSON.stringify(data)}\n\n`);
    };

    // ── Keepalive ping every 15s so the connection doesn't drop on long responses
    const keepalive = setInterval(() => {
      if (!res.writableEnded) res.write(': ping\n\n');
    }, 15000);

    const cleanup = () => clearInterval(keepalive);

    // ── Call Kilo API
    const reqOptions = {
      hostname: 'api.kilo.ai',
      path: '/api/gateway/chat/completions',
      method: 'POST',
      timeout: 300000, // 5 min socket timeout
      headers: {
        'Authorization': `Bearer ${settings.apiKey}`,
        'Content-Type': 'application/json'
      }
    };

    let fullResponse = '';
    // ── Buffer for incomplete SSE lines split across TCP chunks
    let lineBuffer = '';

    const apiReq = https.request(reqOptions, (apiRes) => {
      apiRes.on('data', chunk => {
        // Append chunk to buffer and process complete lines
        lineBuffer += chunk.toString();
        const lines = lineBuffer.split('\n');
        // Keep the last (possibly incomplete) line in the buffer
        lineBuffer = lines.pop();

        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed || trimmed.startsWith(':')) continue; // skip empty / comments
          if (!trimmed.startsWith('data: ')) continue;

          const raw = trimmed.slice(6).trim();
          if (raw === '[DONE]') continue; // handled on 'end'

          try {
            const parsed = JSON.parse(raw);
            const delta  = parsed.choices?.[0]?.delta?.content || '';
            if (delta) {
              fullResponse += delta;
              send({ type: 'token', content: delta });
            }
          } catch {}
        }
      });

      apiRes.on('end', async () => {
        cleanup();
        // Process any remaining buffer content
        if (lineBuffer.trim().startsWith('data: ')) {
          const raw = lineBuffer.trim().slice(6).trim();
          if (raw && raw !== '[DONE]') {
            try {
              const parsed = JSON.parse(raw);
              const delta  = parsed.choices?.[0]?.delta?.content || '';
              if (delta) fullResponse += delta;
            } catch {}
          }
        }

        try {
          const cleanResponse = stripToolCalls(fullResponse);
          const detectedFiles = parseFilesFromAIResponse(cleanResponse);

          if (detectedFiles.length > 0) {
            const written = await writeProjectFiles(detectedFiles);
            send({ type: 'files', files: written.map(f => f.path), count: written.length });
          } else {
            send({ type: 'files', files: [], count: 0 });
          }

          const newHistory = [
            ...history,
            { role: 'user',      content: message,       timestamp: new Date().toISOString(), pinned: false },
            { role: 'assistant', content: cleanResponse,  timestamp: new Date().toISOString(), pinned: false }
          ];
          await fse.writeJson(histPath, newHistory, { spaces: 2 });

          send({ type: 'done' });
          res.end();
        } catch (e) {
          send({ type: 'error', message: e.message });
          res.end();
        }
      });

      apiRes.on('error', (e) => {
        cleanup();
        send({ type: 'error', message: e.message });
        res.end();
      });
    });

    apiReq.on('error', (e) => {
      cleanup();
      send({ type: 'error', message: e.message });
      res.end();
    });

    // ── Abort Kilo request if client disconnects early
    req.on('close', () => {
      cleanup();
      apiReq.destroy();
    });

    apiReq.write(JSON.stringify(body));
    apiReq.end();

  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── CLEAR CHAT HISTORY
router.delete('/:id/chat', async (req, res) => {
  try {
    const projects = await readProjects();
    const project  = projects.find(p => p.id === req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });
    await fse.writeJson(path.join(TABCHAT, project.name, 'history.json'), [], { spaces: 2 });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
