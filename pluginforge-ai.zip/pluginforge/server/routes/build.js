const express = require('express');
const router  = express.Router();
const fse     = require('fs-extra');
const path    = require('path');
const { v4: uuidv4 } = require('uuid');
const { buildProject } = require('../utils/buildManager');

const PROJECTS = path.join(__dirname, '../../data/projects.json');

async function readProjects() { return fse.readJson(PROJECTS).catch(() => []); }
async function writeProjects(d) { await fse.writeJson(PROJECTS, d, { spaces: 2 }); }

// ── TRIGGER BUILD
router.post('/:id/build', async (req, res) => {
  try {
    const projects = await readProjects();
    const idx      = projects.findIndex(p => p.id === req.params.id);
    if (idx === -1) return res.status(404).json({ error: 'Not found' });

    const project = projects[idx];
    const wsClients = req.app.locals.wsClients;
    const wsSet   = wsClients.get(req.params.id) || new Set();

    // Respond immediately — build streams via WebSocket
    res.json({ ok: true, message: 'Build started' });

    const result = await buildProject(project.name, wsSet);

    // Save to build history
    const entry = {
      id: uuidv4(),
      timestamp: new Date().toISOString(),
      success: result.success,
      log: result.log,
      jarPath: result.jarPath
    };
    projects[idx].buildHistory = [entry, ...(projects[idx].buildHistory || [])].slice(0, 10);
    projects[idx].updatedAt = new Date().toISOString();
    await writeProjects(projects);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
