const express  = require('express');
const router   = express.Router();
const fse      = require('fs-extra');
const path     = require('path');
const archiver = require('archiver');
const { getFileTree } = require('../utils/fileManager');

const WORKSPACE = path.join(__dirname, '../../workspace');
const PROJECTS  = path.join(__dirname, '../../data/projects.json');

async function getProject(id) {
  const projects = await fse.readJson(PROJECTS).catch(() => []);
  return projects.find(p => p.id === id);
}

// ── LIST FILES
router.get('/:id/files', async (req, res) => {
  try {
    const project = await getProject(req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });
    const tree = await getFileTree(path.join(WORKSPACE, project.name));
    res.json(tree);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── GET FILE CONTENT
router.get('/:id/files/content', async (req, res) => {
  try {
    const project = await getProject(req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });
    const filePath = req.query.path;
    if (!filePath) return res.status(400).json({ error: 'path query required' });

    // Security: ensure path stays within workspace
    const full = path.resolve(WORKSPACE, project.name, filePath);
    if (!full.startsWith(path.resolve(WORKSPACE, project.name))) {
      return res.status(403).json({ error: 'Forbidden' });
    }

    const content = await fse.readFile(full, 'utf8');
    res.json({ path: filePath, content });
  } catch (e) {
    res.status(404).json({ error: 'File not found' });
  }
});

// ── WRITE FILE
router.post('/:id/files', async (req, res) => {
  try {
    const project = await getProject(req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });
    const { path: filePath, content } = req.body;
    if (!filePath) return res.status(400).json({ error: 'path required' });

    const full = path.resolve(WORKSPACE, project.name, filePath);
    if (!full.startsWith(path.resolve(WORKSPACE, project.name))) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    await fse.ensureDir(path.dirname(full));
    await fse.writeFile(full, content || '', 'utf8');
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── DELETE FILE
router.delete('/:id/files', async (req, res) => {
  try {
    const project = await getProject(req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });
    const filePath = req.query.path;
    const full = path.resolve(WORKSPACE, project.name, filePath);
    if (!full.startsWith(path.resolve(WORKSPACE, project.name))) {
      return res.status(403).json({ error: 'Forbidden' });
    }
    await fse.remove(full);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── DOWNLOAD ZIP
router.get('/:id/download/zip', async (req, res) => {
  try {
    const project = await getProject(req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${project.name}.zip"`);

    const archive = archiver('zip', { zlib: { level: 9 } });
    archive.pipe(res);
    archive.directory(path.join(WORKSPACE, project.name), project.name);
    await archive.finalize();
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── DOWNLOAD JAR
router.get('/:id/download/jar', async (req, res) => {
  try {
    const project = await getProject(req.params.id);
    if (!project) return res.status(404).json({ error: 'Not found' });

    const { getJarPath } = require('../utils/buildManager');
    const jarPath = await getJarPath(project.name);
    if (!jarPath) return res.status(404).json({ error: 'JAR not found. Build first.' });

    res.download(jarPath);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
