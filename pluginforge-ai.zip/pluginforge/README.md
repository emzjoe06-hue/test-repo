# PluginForge AI

Agentic Minecraft Java plugin generator. Runs on Node.js + Express with a multi-panel chat UI. Designed to run on Termux (Android) or any machine with Node.js.

---

## Termux Setup (Android)

### 1. Install dependencies

```bash
pkg update && pkg upgrade
pkg install nodejs openjdk-21 maven git
```

### 2. Get the project

```bash
# Clone or copy the pluginforge/ folder into your Termux home
cd ~
# If cloning from git:
# git clone <your-repo-url> pluginforge
cd pluginforge
```

### 3. Install Node modules

```bash
npm install
```

### 4. Run setup

```bash
npm run setup
```

This will:
- Verify Node.js, Java, and Maven installations
- Create required directories
- Initialize data files

### 5. Start the server

```bash
npm start
```

### 6. Open in browser

Open your Android browser and navigate to:

```
http://localhost:3000
```

Or if accessing from another device on the same network, find your phone's local IP:

```bash
ip addr show wlan0
```

Then open `http://<your-ip>:3000` on any device on the same network.

---

## Getting a Kilo API Key

1. Go to [https://kilo.ai](https://kilo.ai) and create an account
2. Navigate to API Keys in your dashboard
3. Generate a new key
4. In PluginForge AI, click **Settings** (bottom left) and paste your key
5. Click **Test** to verify, then **Save**

---

## Project Structure

```
pluginforge/
  server/           — Node.js + Express backend
    index.js        — Main server entry point
    routes/         — API route handlers
    middleware/     — Auth middleware
    utils/          — File manager, build manager, diff
  frontend/         — Static web UI
    index.html
    css/main.css
    js/             — Modular frontend JS
  workspace/        — Generated plugin source files
    <PluginName>/   — Standard Maven project structure
  tabchat/          — Chat histories per plugin
    <PluginName>/history.json
  data/
    projects.json   — Project metadata
    settings.json   — App settings & API key
  setup.js          — One-time setup script
  package.json
```

---

## Features

- **Agentic plugin generation** — AI expands your idea into a full feature list before writing code
- **Full Maven project** — generates `pom.xml`, `plugin.yml`, `config.yml`, all Java files
- **Live build streaming** — Maven build output streamed line by line via WebSocket
- **File tree browser** — syntax-highlighted file viewer in the right panel
- **Chat history** — persistent per-project, with pinning and search
- **Multi-project** — manage multiple plugins simultaneously
- **Export/Import** — JSON export for backups and sharing
- **ZIP download** — full project as a ZIP
- **JAR download** — compiled plugin ready to drop in your server

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+Enter` | Send message |
| `Ctrl+B` | Trigger build |
| `Ctrl+S` | Export project JSON |
| `Ctrl+K` | Focus project search |
| `Ctrl+[` | Toggle left panel |
| `Ctrl+]` | Toggle right panel |
| `Escape` | Close modal |

---

## Supported AI Models

| Model | Notes |
|-------|-------|
| `kilo-auto/free` | Default, free tier |
| `anthropic/claude-sonnet-4-5` | High quality |
| `google/gemini-2.0-flash` | Fast |
| `arcee-ai/trinity-large-thinking:free` | Reasoning mode |
| `deepseek/deepseek-r1` | Strong coder |

---

## Running as a Background Service (Termux)

To keep the server running after closing the terminal:

```bash
# Install termux-services
pkg install termux-services

# Or simply use nohup:
nohup npm start > pluginforge.log 2>&1 &
echo $! > pluginforge.pid

# To stop:
kill $(cat pluginforge.pid)
```

---

## Troubleshooting

**Maven not found after installing**
```bash
pkg install openjdk-21 maven
# Then restart the server
```

**Port 3000 already in use**
```bash
# Edit .env and change PORT=3000 to any free port
```

**Build fails: JAVA_HOME not set**
```bash
export JAVA_HOME=$(dirname $(dirname $(readlink -f $(which java))))
# Add this to ~/.bashrc to persist
```

**API key 401 errors**
- Verify your key at kilo.ai dashboard
- Make sure you have API credits
- Test the key in Settings > Test

---

## License

MIT
