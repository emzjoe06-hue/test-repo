const express = require('express');
const { exec } = require('child_process');
const fs = require('fs').promises;
const path = require('path');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const WORKSPACE_ROOT = path.join(__dirname, 'workspace');
const HISTORY_FILE = (tabName) => path.join(WORKSPACE_ROOT, tabName, '.chat-history.json');

// ── MODEL REGISTRY
const AZURE_MODELS = {
  'azure-composer':       'bytedance-seed/dola-seed-2.0-pro:free',
  'azure-coder':          'x-ai/grok-code-fast-1:optimized:free',
  'azure-coder-instruct': 'nvidia/nemotron-3-super-120b-a12b:free',
  'azure-code-xl':        'arcee-ai/trinity-large-thinking:free',
  'azure-omni':           'openrouter/free',
  'azure-auto':           'kilo-auto/free',
};

const AZURE_MODEL_INFO = [
  { id: 'azure-composer',       name: 'Azure Composer',       desc: 'General purpose, fast responses',              requiresKey: false },
  { id: 'azure-coder',          name: 'Azure Coder',          desc: 'Optimized for code tasks',                     requiresKey: false },
  { id: 'azure-coder-instruct', name: 'Azure Coder Instruct', desc: 'Large model, deep reasoning',                  requiresKey: false },
  { id: 'azure-code-xl',        name: 'Azure Code XL',        desc: 'Extended thinking, complex problems',          requiresKey: false },
  { id: 'azure-omni',           name: 'Azure Omni',           desc: 'Best available free model',                    requiresKey: false },
  { id: 'azure-auto',           name: 'Azure Auto',           desc: 'Auto-routes to best model (API key required)', requiresKey: true  },
];

// ── WORKSPACE HELPERS
async function ensureWorkspace(tabName) {
  const dir = path.join(WORKSPACE_ROOT, tabName);
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

async function listDir(base, current) {
  const entries = await fs.readdir(current, { withFileTypes: true });
  let result = [];
  for (const entry of entries) {
    if (entry.name.startsWith('.')) continue;
    const fullPath = path.join(current, entry.name);
    const relPath = path.relative(base, fullPath);
    if (entry.isDirectory()) {
      result.push({ name: relPath, type: 'dir' });
      result = result.concat(await listDir(base, fullPath));
    } else {
      result.push({ name: relPath, type: 'file' });
    }
  }
  return result;
}

// ── HISTORY PERSISTENCE
async function loadHistory(tabName) {
  try {
    await ensureWorkspace(tabName);
    const raw = await fs.readFile(HISTORY_FILE(tabName), 'utf-8');
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

async function saveHistory(tabName, messages) {
  try {
    await ensureWorkspace(tabName);
    await fs.writeFile(HISTORY_FILE(tabName), JSON.stringify(messages, null, 2), 'utf-8');
  } catch (e) {
    console.error('History save error:', e.message);
  }
}

// ── REST ROUTES
app.get('/api/models', (req, res) => res.json(AZURE_MODEL_INFO));

app.get('/api/workspace/:tab/files', async (req, res) => {
  try {
    const dir = await ensureWorkspace(req.params.tab);
    res.json({ files: await listDir(dir, dir) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/workspace/:tab/file', async (req, res) => {
  try {
    const dir = await ensureWorkspace(req.params.tab);
    const filePath = path.join(dir, req.query.path || '');
    if (!filePath.startsWith(dir)) return res.status(403).json({ error: 'Forbidden' });
    res.json({ content: await fs.readFile(filePath, 'utf-8') });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/workspace/:tab/file', async (req, res) => {
  try {
    const dir = await ensureWorkspace(req.params.tab);
    const filePath = path.join(dir, req.body.path || '');
    if (!filePath.startsWith(dir)) return res.status(403).json({ error: 'Forbidden' });
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, req.body.content || '', 'utf-8');
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/workspace/:tab/history', async (req, res) => {
  try { res.json({ history: await loadHistory(req.params.tab) }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/workspace/:tab/history', async (req, res) => {
  try { await saveHistory(req.params.tab, req.body.messages || []); res.json({ ok: true }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/workspace/:tab/history', async (req, res) => {
  try { await saveHistory(req.params.tab, []); res.json({ ok: true }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// ── ACTION HELPERS
function parseActions(text) {
  const actions = [];
  for (const m of [...text.matchAll(/<cmd>([\s\S]*?)<\/cmd>/g)])
    actions.push({ type: 'cmd', content: m[1].trim(), detail: m[1].trim().substring(0, 60) });
  for (const m of [...text.matchAll(/<write\s+path="([^"]+)">([\s\S]*?)<\/write>/g)])
    actions.push({ type: 'write', path: m[1], content: m[2], detail: m[1] });
  for (const m of [...text.matchAll(/<read\s+path="([^"]+)"\s*\/?>/g)])
    actions.push({ type: 'read', path: m[1], detail: m[1] });

  const cleanText = text
    .replace(/<think>[\s\S]*?<\/think>/g, '')
    .replace(/<cmd>[\s\S]*?<\/cmd>/g, '')
    .replace(/<write\s+path="[^"]+">[\s\S]*?<\/write>/g, '')
    .replace(/<read\s+path="[^"]+"\s*\/?>/g, '')
    .trim();

  return { cleanText, actions };
}

async function executeAction(action, workspaceDir) {
  if (action.type === 'cmd') {
    return new Promise((resolve) => {
      exec(action.content, { cwd: workspaceDir, timeout: 30000 }, (err, stdout, stderr) => {
        let out = '';
        if (stdout) out += stdout;
        if (stderr) out += stderr;
        if (err && !out) out = err.message;
        resolve(out.substring(0, 3000) || '(no output)');
      });
    });
  }
  if (action.type === 'write') {
    const fp = path.join(workspaceDir, action.path);
    if (!fp.startsWith(workspaceDir)) throw new Error('Path outside workspace');
    await fs.mkdir(path.dirname(fp), { recursive: true });
    await fs.writeFile(fp, action.content, 'utf-8');
    return `File written: ${action.path} (${action.content.length} bytes)`;
  }
  if (action.type === 'read') {
    const fp = path.join(workspaceDir, action.path);
    if (!fp.startsWith(workspaceDir)) throw new Error('Path outside workspace');
    return (await fs.readFile(fp, 'utf-8')).substring(0, 3000);
  }
  return 'Unknown action';
}

// ── WEBSOCKET — main chat transport
const activeJobs = new Map();

wss.on('connection', (ws) => {
  ws.on('message', async (raw) => {
    let payload;
    try { payload = JSON.parse(raw); } catch { return; }

    const send = (data) => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); };

    if (payload.type === 'abort') {
      const ctrl = activeJobs.get(ws);
      if (ctrl) { ctrl.abort(); activeJobs.delete(ws); }
      send({ type: 'aborted' });
      return;
    }

    if (payload.type === 'chat') {
      const { messages, model, apiKey, tab, persona } = payload;
      const realModel = AZURE_MODELS[model] || 'openrouter/free';
      const workspaceDir = await ensureWorkspace(tab || 'default');

      const ctrl = new AbortController();
      activeJobs.set(ws, ctrl);

      const personaPrefix = persona ? `${persona}\n\n` : '';
      const systemPrompt = `${personaPrefix}You are an agentic AI assistant running on a local machine. Your workspace is: ${workspaceDir}

You can perform tasks by outputting special action blocks. The system will execute them and return results.

AVAILABLE ACTIONS:
<cmd>shell command here</cmd>        → Runs a shell command in the workspace directory.
<write path="relative/path">...</write>  → Creates or overwrites a file.
<read path="relative/path"/>         → Reads a file from the workspace.
<think>your internal reasoning</think>   → Internal reasoning, not shown to user.

RULES:
- Be proactive and autonomous. If a task requires multiple steps, do them all.
- After each action you receive the result and can continue.
- Always confirm what you did and what happened.
- You can install packages, run scripts, create projects, browse via curl, etc.
- The workspace path is: ${workspaceDir}
- Be concise in responses but thorough in actions.`;

      const allMessages = [{ role: 'system', content: systemPrompt }, ...messages];
      let iterations = 0;
      const MAX_ITERATIONS = 10;

      try {
        while (iterations < MAX_ITERATIONS) {
          if (ctrl.signal.aborted) break;
          iterations++;
          send({ type: 'iteration', current: iterations, max: MAX_ITERATIONS });

          const headers = { 'Content-Type': 'application/json' };
          if (apiKey) headers['Authorization'] = `Bearer ${apiKey}`;
          else if (process.env.KILO_API_KEY) headers['Authorization'] = `Bearer ${process.env.KILO_API_KEY}`;

          const response = await fetch('https://api.kilo.ai/api/gateway/chat/completions', {
            method: 'POST',
            headers,
            signal: ctrl.signal,
            body: JSON.stringify({ model: realModel, messages: allMessages, stream: false, max_tokens: 4096 }),
          });

          if (!response.ok) {
            const err = await response.text();
            send({ type: 'error', content: `API Error: ${err}` });
            break;
          }

          const data = await response.json();
          const assistantMsg = data.choices?.[0]?.message?.content || '';
          const { cleanText, actions } = parseActions(assistantMsg);

          if (cleanText.trim()) send({ type: 'text', content: cleanText });
          allMessages.push({ role: 'assistant', content: assistantMsg });

          if (actions.length === 0) break;

          let toolResults = '';
          for (const action of actions) {
            if (ctrl.signal.aborted) break;
            send({ type: 'action', action: action.type, detail: action.detail });
            let result = '';
            try { result = await executeAction(action, workspaceDir); }
            catch (e) { result = `ERROR: ${e.message}`; }
            send({ type: 'result', action: action.type, content: result });
            toolResults += `\n[${action.type.toUpperCase()} RESULT]\n${result}\n`;
          }

          allMessages.push({
            role: 'user',
            content: `Action results:${toolResults}\nContinue with the task if needed, or summarize what was accomplished.`,
          });
        }
      } catch (e) {
        if (e.name !== 'AbortError') send({ type: 'error', content: e.message });
      }

      send({ type: 'done' });
      activeJobs.delete(ws);
    }
  });

  ws.on('close', () => {
    const ctrl = activeJobs.get(ws);
    if (ctrl) ctrl.abort();
    activeJobs.delete(ws);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`\nAzure Agent running at http://localhost:${PORT}`);
  console.log(`Workspace root: ${WORKSPACE_ROOT}`);
  console.log(`WebSocket: ws://localhost:${PORT}`);
});
