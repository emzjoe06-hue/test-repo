// ── THE CODERS SQUAD — server.js
// Web server for the multi-agent dev team UI
// Run: node server.js
// Then open http://localhost:3000

'use strict';

const http    = require('http');
const fs      = require('fs');
const path    = require('path');
const https   = require('https');

const PORT = process.env.PORT || 3000;
const KILO_API_BASE = 'https://api.kilo.ai/api/gateway';

// ── FREE MODELS (fetched from api.kilo.ai/api/gateway/models isFree=true)
const FREE_MODELS = [
  { id: 'kilo-auto/free',                          name: 'Kilo Auto Free',                  ctx: 204800  },
  { id: 'x-ai/grok-code-fast-1:optimized:free',    name: 'xAI Grok Code Fast (free)',        ctx: 256000  },
  { id: 'stepfun/step-3.5-flash:free',              name: 'StepFun Step 3.5 Flash (free)',    ctx: 262144  },
  { id: 'openrouter/elephant-alpha',                name: 'Elephant Alpha (free)',            ctx: 262144  },
  { id: 'nvidia/nemotron-3-super-120b-a12b:free',   name: 'NVIDIA Nemotron 3 Super (free)',   ctx: 262144  },
  { id: 'openrouter/free',                          name: 'Free Models Router',               ctx: 200000  },
  { id: 'arcee-ai/trinity-large-thinking:free',     name: 'Arcee Trinity Large (free)',       ctx: 262144  },
  { id: 'bytedance-seed/dola-seed-2.0-pro:free',    name: 'ByteDance Dola Seed 2.0 (free)',  ctx: 131072  },
];

// ── AGENT DEFINITIONS
const AGENTS = {
  supervisor: {
    id:    'supervisor',
    name:  'The Lead',
    role:  'Supervisor',
    color: '#f0f0f4',
    desc:  'Breaks down tasks, assigns work to specialists, synthesizes final output. Never writes code directly.',
    system: `You are The Lead — a senior software architect and project supervisor for The Coders Squad.
Your job: analyze the user's request, produce a clear build plan, delegate specific tasks to your four specialist agents (Architect, Builder, Reviewer, Debugger), and synthesize all their outputs into a final deliverable.

Format your plan as JSON:
{
  "summary": "short one-liner of what we are building",
  "tasks": [
    { "agent": "architect", "task": "..." },
    { "agent": "builder",   "task": "..." },
    { "agent": "reviewer",  "task": "..." },
    { "agent": "debugger",  "task": "..." }
  ],
  "final_instructions": "..."
}

Be concise. Focus on the user's goal. Produce valid JSON only.`
  },

  architect: {
    id:    'architect',
    name:  'Arch',
    role:  'Architect',
    color: '#48cc84',
    desc:  'System design, data models, API contracts, folder structure.',
    system: `You are Arch — a systems architect on The Coders Squad.
Your specialty: system design, data models, API contracts, folder structures, and technology decisions.
You receive a specific task from The Lead. Produce clear, concise architectural output.
Be technical. Use code blocks when showing structures. No fluff.`
  },

  builder: {
    id:    'builder',
    name:  'Dev',
    role:  'Builder',
    color: '#5b8af0',
    desc:  'Writes the actual code. Full implementations, no placeholders.',
    system: `You are Dev — the primary code writer on The Coders Squad.
Your specialty: writing complete, production-ready code. No TODOs, no placeholders, no stubs.
You receive a specific task from The Lead plus the architect's design. Implement it fully.
Output code in properly labeled code blocks with language tags. Be thorough.`
  },

  reviewer: {
    id:    'reviewer',
    name:  'Rev',
    role:  'Reviewer',
    color: '#d48830',
    desc:  'Code review, best practices, security, performance audit.',
    system: `You are Rev — the code reviewer on The Coders Squad.
Your specialty: finding bugs, security issues, performance bottlenecks, and style violations.
You receive code from the Builder. Review it critically. Output:
1. Issues found (with severity: critical / warning / suggestion)
2. Fixed code if needed
3. Final verdict: APPROVED or NEEDS_WORK

Be direct. Do not praise code. Find what's wrong.`
  },

  debugger: {
    id:    'debugger',
    name:  'Fix',
    role:  'Debugger',
    color: '#e05555',
    desc:  'Traces errors, fixes bugs, handles edge cases.',
    system: `You are Fix — the debugger on The Coders Squad.
Your specialty: tracing errors, fixing bugs, handling edge cases, writing tests.
You receive the final code and review. Your job: apply any critical fixes, add error handling, and write at least 3 test cases.
Output the final clean code + tests. Mark every change with a // FIX: comment.`
  }
};

// ── MIME TYPES
const MIME = {
  '.html': 'text/html',
  '.css':  'text/css',
  '.js':   'application/javascript',
  '.json': 'application/json',
  '.ico':  'image/x-icon',
};

// ── KILO API CALL (streaming passthrough)
function callKilo(apiKey, model, messages, systemPrompt, res) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      model,
      max_tokens: 4096,
      stream: true,
      messages,
      ...(systemPrompt ? { system: systemPrompt } : {})
    });

    const url = new URL(`${KILO_API_BASE}/chat/completions`);
    const options = {
      hostname: url.hostname,
      port:     443,
      path:     url.pathname,
      method:   'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${apiKey}`,
        'Content-Length': Buffer.byteLength(body)
      }
    };

    const req = https.request(options, (apiRes) => {
      let fullText = '';
      apiRes.on('data', (chunk) => {
        const str = chunk.toString();
        // Parse SSE and forward to client
        const lines = str.split('\n');
        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6).trim();
            if (data === '[DONE]') continue;
            try {
              const parsed = JSON.parse(data);
              const delta = parsed.choices?.[0]?.delta?.content || '';
              if (delta) {
                fullText += delta;
                res.write(`data: ${JSON.stringify({ delta })}\n\n`);
              }
            } catch {}
          }
        }
      });
      apiRes.on('end', () => resolve(fullText));
      apiRes.on('error', reject);
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ── KILO API CALL (non-streaming, returns text)
function callKiloSync(apiKey, model, messages, systemPrompt) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({
      model,
      max_tokens: 4096,
      stream: false,
      messages,
      ...(systemPrompt ? { system: systemPrompt } : {})
    });

    const url = new URL(`${KILO_API_BASE}/chat/completions`);
    const options = {
      hostname: url.hostname,
      port:     443,
      path:     url.pathname,
      method:   'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${apiKey}`,
        'Content-Length': Buffer.byteLength(body)
      }
    };

    const req = https.request(options, (apiRes) => {
      let raw = '';
      apiRes.on('data', c => raw += c);
      apiRes.on('end', () => {
        try {
          const parsed = JSON.parse(raw);
          if (parsed.error) return reject(new Error(parsed.error.message || JSON.stringify(parsed.error)));
          resolve(parsed.choices?.[0]?.message?.content || '');
        } catch (e) { reject(e); }
      });
    });

    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ── HTTP SERVER
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);

  // ── STATIC FILES
  if (req.method === 'GET' && !url.pathname.startsWith('/api/')) {
    let filePath = url.pathname === '/' ? '/index.html' : url.pathname;
    filePath = path.join(__dirname, 'public', filePath);
    const ext = path.extname(filePath);
    try {
      const data = fs.readFileSync(filePath);
      res.writeHead(200, { 'Content-Type': MIME[ext] || 'text/plain' });
      res.end(data);
    } catch {
      res.writeHead(404); res.end('Not found');
    }
    return;
  }

  // ── API: GET /api/models
  if (req.method === 'GET' && url.pathname === '/api/models') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ models: FREE_MODELS, agents: AGENTS }));
    return;
  }

  // ── API: POST /api/run  — full squad pipeline (SSE)
  if (req.method === 'POST' && url.pathname === '/api/run') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', async () => {
      let payload;
      try { payload = JSON.parse(body); } catch {
        res.writeHead(400); res.end('Bad JSON'); return;
      }

      const { apiKey, model, prompt, history = [] } = payload;
      if (!apiKey || !model || !prompt) {
        res.writeHead(400); res.end('Missing apiKey, model, or prompt'); return;
      }

      // SSE headers
      res.writeHead(200, {
        'Content-Type':  'text/event-stream',
        'Cache-Control': 'no-cache',
        'Connection':    'keep-alive',
        'Access-Control-Allow-Origin': '*'
      });

      const send = (event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);

      try {
        // ── PHASE 1: Supervisor plans
        send('phase', { agent: 'supervisor', status: 'thinking' });

        const supervisorMessages = [
          ...history,
          { role: 'user', content: prompt }
        ];

        let planRaw = '';
        try {
          planRaw = await callKiloSync(apiKey, model, supervisorMessages, AGENTS.supervisor.system);
        } catch (e) {
          send('error', { message: `Supervisor failed: ${e.message}` });
          res.end(); return;
        }

        // Parse plan JSON
        let plan;
        try {
          const jsonMatch = planRaw.match(/\{[\s\S]*\}/);
          plan = JSON.parse(jsonMatch ? jsonMatch[0] : planRaw);
        } catch {
          plan = {
            summary: 'Building your request',
            tasks: [
              { agent: 'architect', task: prompt },
              { agent: 'builder',   task: prompt },
              { agent: 'reviewer',  task: 'Review the code above' },
              { agent: 'debugger',  task: 'Debug and finalize the code above' }
            ],
            final_instructions: 'Combine all outputs into a final deliverable'
          };
        }

        send('plan', { plan, raw: planRaw });

        // ── PHASE 2: Run specialists sequentially, building context
        const outputs = {};
        const agentOrder = ['architect', 'builder', 'reviewer', 'debugger'];

        for (const agentId of agentOrder) {
          const task = plan.tasks?.find(t => t.agent === agentId)?.task || prompt;
          const agent = AGENTS[agentId];

          send('phase', { agent: agentId, status: 'working', task });

          // Build context from previous agents
          let contextMsg = `Your task: ${task}\n`;
          if (agentId === 'builder' && outputs.architect) {
            contextMsg += `\nArchitect's design:\n${outputs.architect}`;
          }
          if (agentId === 'reviewer' && outputs.builder) {
            contextMsg += `\nCode to review:\n${outputs.builder}`;
          }
          if (agentId === 'debugger') {
            if (outputs.builder)   contextMsg += `\nCode:\n${outputs.builder}`;
            if (outputs.reviewer)  contextMsg += `\nReview:\n${outputs.reviewer}`;
          }

          let agentOutput = '';
          try {
            // Stream this agent's output
            const streamBody = JSON.stringify({
              model,
              max_tokens: 4096,
              stream: true,
              system: agent.system,
              messages: [{ role: 'user', content: contextMsg }]
            });

            const urlObj = new URL(`${KILO_API_BASE}/chat/completions`);
            await new Promise((resolve, reject) => {
              const reqOpts = {
                hostname: urlObj.hostname,
                port: 443,
                path: urlObj.pathname,
                method: 'POST',
                headers: {
                  'Content-Type':  'application/json',
                  'Authorization': `Bearer ${apiKey}`,
                  'Content-Length': Buffer.byteLength(streamBody)
                }
              };

              const kiloReq = https.request(reqOpts, (kiloRes) => {
                kiloRes.on('data', (chunk) => {
                  const lines = chunk.toString().split('\n');
                  for (const line of lines) {
                    if (!line.startsWith('data: ')) continue;
                    const d = line.slice(6).trim();
                    if (d === '[DONE]') return;
                    try {
                      const p = JSON.parse(d);
                      const delta = p.choices?.[0]?.delta?.content || '';
                      if (delta) {
                        agentOutput += delta;
                        send('delta', { agent: agentId, delta });
                      }
                    } catch {}
                  }
                });
                kiloRes.on('end', resolve);
                kiloRes.on('error', reject);
              });
              kiloReq.on('error', reject);
              kiloReq.write(streamBody);
              kiloReq.end();
            });

          } catch (e) {
            agentOutput = `[Error: ${e.message}]`;
            send('delta', { agent: agentId, delta: agentOutput });
          }

          outputs[agentId] = agentOutput;
          send('agent_done', { agent: agentId });
        }

        // ── PHASE 3: Supervisor synthesizes
        send('phase', { agent: 'supervisor', status: 'synthesizing' });

        const synthPrompt = `The team has completed their work. Here are all outputs:

ARCHITECT:
${outputs.architect || 'N/A'}

BUILDER:
${outputs.builder || 'N/A'}

REVIEWER:
${outputs.reviewer || 'N/A'}

DEBUGGER:
${outputs.debugger || 'N/A'}

${plan.final_instructions || 'Synthesize the above into a clear final deliverable for the user.'}

Provide a clean final summary and the production-ready code/output.`;

        let finalOutput = '';
        try {
          const synthBody = JSON.stringify({
            model,
            max_tokens: 4096,
            stream: true,
            system: `You are The Lead — supervisor of The Coders Squad. Synthesize your team's work into a polished final deliverable. Be concise. Show final code clearly.`,
            messages: [{ role: 'user', content: synthPrompt }]
          });

          const urlObj = new URL(`${KILO_API_BASE}/chat/completions`);
          await new Promise((resolve, reject) => {
            const reqOpts = {
              hostname: urlObj.hostname,
              port: 443,
              path: urlObj.pathname,
              method: 'POST',
              headers: {
                'Content-Type':  'application/json',
                'Authorization': `Bearer ${apiKey}`,
                'Content-Length': Buffer.byteLength(synthBody)
              }
            };

            const kiloReq = https.request(reqOpts, (kiloRes) => {
              kiloRes.on('data', (chunk) => {
                const lines = chunk.toString().split('\n');
                for (const line of lines) {
                  if (!line.startsWith('data: ')) continue;
                  const d = line.slice(6).trim();
                  if (d === '[DONE]') return;
                  try {
                    const p = JSON.parse(d);
                    const delta = p.choices?.[0]?.delta?.content || '';
                    if (delta) {
                      finalOutput += delta;
                      send('delta', { agent: 'supervisor', delta });
                    }
                  } catch {}
                }
              });
              kiloRes.on('end', resolve);
              kiloRes.on('error', reject);
            });
            kiloReq.on('error', reject);
            kiloReq.write(synthBody);
            kiloReq.end();
          });

        } catch (e) {
          finalOutput = `[Synthesis error: ${e.message}]`;
          send('delta', { agent: 'supervisor', delta: finalOutput });
        }

        send('done', {
          summary: plan.summary,
          outputs: { ...outputs, final: finalOutput }
        });

      } catch (e) {
        send('error', { message: e.message });
      }

      res.end();
    });
    return;
  }

  // ── OPTIONS (CORS preflight)
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type'
    });
    res.end();
    return;
  }

  res.writeHead(404); res.end('Not found');
});

server.listen(PORT, () => {
  console.log(`\n  The Coders Squad running at http://localhost:${PORT}\n`);
});
