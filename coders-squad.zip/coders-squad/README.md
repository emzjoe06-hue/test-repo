# The Coders Squad

A multi-agent dev team running entirely in your browser.
**1 Supervisor + 4 Specialists. 100% free models via Kilo AI.**

```
[The Lead]   — Supervisor: plans, delegates, synthesizes
[Arch]       — Architect: system design & structure
[Dev]        — Builder: writes production code
[Rev]        — Reviewer: security, bugs, best practices
[Fix]        — Debugger: error handling, tests, final fixes
```

---

## Setup on Termux

```bash
# 1. Install Node
pkg update && pkg install nodejs

# 2. Clone or copy files to Termux
mkdir ~/coders-squad && cd ~/coders-squad
# (copy all files here)

# 3. Start the server
node server.js

# 4. Open in browser
# http://localhost:3000
```

---

## Free Models Included

| Model | Context |
|---|---|
| Kilo Auto Free | 200K |
| xAI Grok Code Fast (free) | 256K |
| StepFun Step 3.5 Flash (free) | 262K |
| Elephant Alpha (free) | 262K |
| NVIDIA Nemotron 3 Super (free) | 262K |
| Free Models Router | 200K |
| Arcee Trinity Large (free) | 262K |
| ByteDance Dola Seed (free) | 131K |

All sourced from `api.kilo.ai/api/gateway/models` where `isFree: true`.

---

## API Key

Get a free key at [kilo.ai](https://kilo.ai). Required to call the models.
