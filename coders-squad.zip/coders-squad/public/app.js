// ── THE CODERS SQUAD — app.js
'use strict';

// ── STATE
let apiKey    = localStorage.getItem('cs_api_key') || '';
let model     = localStorage.getItem('cs_model')   || 'kilo-auto/free';
let history   = [];
let running   = false;
let agentData = {};

const FREE_MODELS = [
  { id: 'kilo-auto/free',                         name: 'Kilo Auto Free',               ctx: '200K' },
  { id: 'x-ai/grok-code-fast-1:optimized:free',   name: 'xAI Grok Code Fast (free)',    ctx: '256K' },
  { id: 'stepfun/step-3.5-flash:free',             name: 'StepFun 3.5 Flash (free)',     ctx: '262K' },
  { id: 'openrouter/elephant-alpha',               name: 'Elephant Alpha (free)',         ctx: '262K' },
  { id: 'nvidia/nemotron-3-super-120b-a12b:free',  name: 'NVIDIA Nemotron 3 (free)',     ctx: '262K' },
  { id: 'openrouter/free',                         name: 'Free Models Router',            ctx: '200K' },
  { id: 'arcee-ai/trinity-large-thinking:free',    name: 'Arcee Trinity Large (free)',    ctx: '262K' },
  { id: 'bytedance-seed/dola-seed-2.0-pro:free',   name: 'ByteDance Dola Seed (free)',   ctx: '131K' },
];

const AGENTS_META = {
  supervisor: { name: 'The Lead',  role: 'Supervisor', color: '#f0f0f4' },
  architect:  { name: 'Arch',      role: 'Architect',  color: '#48cc84' },
  builder:    { name: 'Dev',       role: 'Builder',    color: '#5b8af0' },
  reviewer:   { name: 'Rev',       role: 'Reviewer',   color: '#d48830' },
  debugger:   { name: 'Fix',       role: 'Debugger',   color: '#e05555' },
};

// ── DOM HELPERS
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

function toast(msg, type = '') {
  const wrap = document.getElementById('toast-wrap');
  if (!wrap) return;
  const el = document.createElement('div');
  el.className = `toast${type ? ' ' + type : ''}`;
  el.textContent = msg;
  wrap.appendChild(el);
  setTimeout(() => el.remove(), 3500);
}

// ── MARKDOWN RENDERER (lightweight)
function renderMd(text) {
  if (!text) return '';
  let html = text
    // Escape HTML
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    // Code blocks
    .replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) =>
      `<pre><code class="lang-${lang}">${code.trim()}</code></pre>`)
    // Inline code
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    // Bold
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    // Italic
    .replace(/_(.+?)_/g, '<em>$1</em>')
    // H3
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    // H2
    .replace(/^## (.+)$/gm, '<h2>$1</h2>')
    // H1
    .replace(/^# (.+)$/gm, '<h1>$1</h1>')
    // List items
    .replace(/^[-*] (.+)$/gm, '<li>$1</li>')
    // Numbered list
    .replace(/^\d+\. (.+)$/gm, '<li>$1</li>')
    // Wrap consecutive LI
    .replace(/(<li>.*<\/li>\n?)+/g, m => `<ul>${m}</ul>`)
    // Paragraphs (double newline)
    .replace(/\n\n/g, '</p><p>')
    // Single newlines in paragraphs
    .replace(/\n/g, '<br>');

  return `<div class="md-output"><p>${html}</p></div>`;
}

// ── CANVAS BACKGROUND (setup screen)
function initCanvas(canvas) {
  const ctx = canvas.getContext('2d');
  let cells = [];
  const CELL = 40;

  function resize() {
    canvas.width  = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    buildCells();
  }

  function buildCells() {
    cells = [];
    const cols = Math.ceil(canvas.width  / CELL) + 1;
    const rows = Math.ceil(canvas.height / CELL) + 1;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        if (Math.random() < 0.08) {
          cells.push({
            x: c * CELL, y: r * CELL,
            vy: -(0.2 + Math.random() * 0.4),
            alpha: 0.15 + Math.random() * 0.25,
            color: Math.random() < 0.5 ? '#18142a' : '#1c1634',
            w: CELL - 2, h: CELL - 2
          });
        }
      }
    }
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    // grid dots
    ctx.fillStyle = '#1c1c28';
    for (let x = 0; x < canvas.width; x += CELL) {
      for (let y = 0; y < canvas.height; y += CELL) {
        ctx.beginPath();
        ctx.arc(x, y, 1, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    // falling cells
    for (const c of cells) {
      ctx.globalAlpha = c.alpha;
      ctx.fillStyle = c.color;
      ctx.fillRect(c.x, c.y, c.w, c.h);
      c.y += c.vy;
      if (c.y + c.h < 0) c.y = canvas.height;
    }
    ctx.globalAlpha = 1;
    requestAnimationFrame(draw);
  }

  resize();
  window.addEventListener('resize', resize);
  draw();
}

// ── RENDER SETUP SCREEN
function renderSetup() {
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="setup-screen">
      <canvas class="setup-canvas" id="setup-canvas"></canvas>
      <div class="setup-card">
        <div class="setup-logo">
          <div class="setup-logo-mark"><span>CS</span></div>
          <div class="setup-logo-text">
            <h1>The Coders Squad</h1>
            <p>1 Supervisor · 4 Specialists · 100% Free Models</p>
          </div>
        </div>

        <div class="setup-field">
          <label class="setup-label">Kilo AI API Key</label>
          <input
            id="api-key-input"
            class="setup-input"
            type="password"
            placeholder="kilo_..."
            value="${apiKey}"
            autocomplete="off"
          >
          <div class="setup-hint">Get yours at kilo.ai — required to call the models</div>
        </div>

        <div class="setup-field">
          <label class="setup-label">Free Model — pick one</label>
          <div class="setup-models-grid" id="models-grid">
            ${FREE_MODELS.map(m => `
              <div class="model-pill${m.id === model ? ' selected' : ''}" data-id="${m.id}">
                <div class="model-pill-name">${m.name}</div>
                <div class="model-pill-badge">FREE · ${m.ctx} ctx</div>
              </div>
            `).join('')}
          </div>
        </div>

        <button class="setup-btn" id="launch-btn">Launch The Squad</button>
      </div>
    </div>
    <div class="toast-wrap" id="toast-wrap"></div>
  `;

  initCanvas(document.getElementById('setup-canvas'));

  // Model selection
  $$('.model-pill').forEach(pill => {
    pill.addEventListener('click', () => {
      $$('.model-pill').forEach(p => p.classList.remove('selected'));
      pill.classList.add('selected');
      model = pill.dataset.id;
    });
  });

  // Launch
  document.getElementById('launch-btn').addEventListener('click', () => {
    const key = document.getElementById('api-key-input').value.trim();
    if (!key) { toast('Enter your Kilo AI API key', 'error'); return; }
    apiKey = key;
    localStorage.setItem('cs_api_key', apiKey);
    localStorage.setItem('cs_model', model);
    renderShell();
  });
}

// ── RENDER MAIN SHELL
function renderShell() {
  const app = document.getElementById('app');
  const modelName = FREE_MODELS.find(m2 => m2.id === model)?.name || model;

  app.innerHTML = `
    <div class="shell">
      <div class="topbar">
        <div class="topbar-left">
          <div class="logo">
            <div class="logo-mark"><span>CS</span></div>
            The Coders Squad
          </div>
          <div class="topbar-sep"></div>
          <div class="topbar-model" id="topbar-model">${modelName}</div>
        </div>
        <div class="topbar-right">
          <button class="tb-btn" id="clear-btn">Clear</button>
          <button class="tb-btn" id="settings-btn">Settings</button>
        </div>
      </div>

      <div class="main-layout">
        <div class="sidebar">
          <div class="sb-section">
            <div class="sb-label">The Team</div>
            ${Object.entries(AGENTS_META).map(([id, a]) => `
              <div class="agent-card" id="agent-card-${id}" data-agent="${id}">
                <div class="agent-card-top">
                  <div class="agent-dot" id="agent-dot-${id}" style="background:${a.color}"></div>
                  <div>
                    <div class="agent-name">${a.name}</div>
                    <div class="agent-role">${a.role}</div>
                  </div>
                </div>
                <div class="agent-status" id="agent-status-${id}">// idle</div>
              </div>
            `).join('')}
          </div>
          <div class="sb-history" id="sb-history">
            <div class="sb-label">History</div>
            <div id="history-list"></div>
          </div>
        </div>

        <div class="main-content">
          <div class="chat-area" id="chat-area">
            <div class="empty-state" id="empty-state">
              <svg class="empty-state-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
                <rect x="3" y="3" width="18" height="18" rx="2"/>
                <path d="M8 12h8M8 8h8M8 16h5"/>
              </svg>
              <p>Your dev team is ready</p>
              <small>// describe what you want to build</small>
            </div>
          </div>

          <div class="input-area">
            <div class="input-row">
              <div class="input-wrap">
                <textarea
                  id="main-input"
                  class="main-input"
                  placeholder="What should the squad build?  (Shift+Enter for newline)"
                  rows="1"
                ></textarea>
              </div>
              <button class="send-btn" id="send-btn">Run Squad</button>
            </div>
            <div class="input-meta">
              <span class="input-hint" id="status-hint">// ready</span>
              <span class="input-hint" id="model-hint">${model}</span>
            </div>
          </div>

          <div class="status-bar">
            <div class="status-item">
              <div class="status-dot online"></div>
              <span>kilo.ai gateway</span>
            </div>
            <div class="status-item" id="status-agents">
              <span>5 agents loaded</span>
            </div>
            <div class="status-item" id="status-run">
              <span>// waiting for input</span>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="toast-wrap" id="toast-wrap"></div>
  `;

  // Auto-resize textarea
  const input = document.getElementById('main-input');
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 160) + 'px';
  });

  // Enter to send, Shift+Enter for newline
  input.addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      doRun();
    }
  });

  document.getElementById('send-btn').addEventListener('click', doRun);
  document.getElementById('clear-btn').addEventListener('click', doClear);
  document.getElementById('settings-btn').addEventListener('click', () => {
    localStorage.removeItem('cs_api_key');
    renderSetup();
  });
}

// ── SET AGENT STATUS
function setAgentStatus(agentId, status, label) {
  const dot    = document.getElementById(`agent-dot-${agentId}`);
  const statEl = document.getElementById(`agent-status-${agentId}`);
  if (!statEl) return;
  statEl.className = `agent-status ${status}`;
  statEl.textContent = label;
  if (dot && status === 'working') dot.classList.add('working');
  else if (dot) dot.classList.remove('working');
}

function resetAgentStatuses() {
  Object.keys(AGENTS_META).forEach(id => setAgentStatus(id, '', '// idle'));
}

// ── CLEAR
function doClear() {
  history = [];
  resetAgentStatuses();
  const chat = document.getElementById('chat-area');
  if (chat) {
    chat.innerHTML = `
      <div class="empty-state" id="empty-state">
        <svg class="empty-state-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1">
          <rect x="3" y="3" width="18" height="18" rx="2"/>
          <path d="M8 12h8M8 8h8M8 16h5"/>
        </svg>
        <p>Your dev team is ready</p>
        <small>// describe what you want to build</small>
      </div>
    `;
  }
  document.getElementById('status-hint').textContent = '// ready';
}

// ── MAIN RUN
async function doRun() {
  if (running) return;
  const input  = document.getElementById('main-input');
  const prompt = input.value.trim();
  if (!prompt) return;

  running = true;
  input.value = '';
  input.style.height = 'auto';
  document.getElementById('send-btn').disabled = true;
  document.getElementById('status-hint').textContent = '// running squad...';

  // Remove empty state
  const emptyState = document.getElementById('empty-state');
  if (emptyState) emptyState.remove();

  const chat = document.getElementById('chat-area');

  // User message
  const userEl = document.createElement('div');
  userEl.className = 'msg-block msg-user';
  userEl.innerHTML = `<div class="msg-user-bubble">${escHtml(prompt)}</div>`;
  chat.appendChild(userEl);
  chat.scrollTop = chat.scrollHeight;

  // Squad block container
  const squadEl = document.createElement('div');
  squadEl.className = 'msg-block squad-block';
  squadEl.id = 'active-squad';
  chat.appendChild(squadEl);

  // Phase containers
  const planHolder    = document.createElement('div');
  const agentHolders  = {};
  const finalHolder   = document.createElement('div');
  squadEl.appendChild(planHolder);

  const agentOrder = ['architect', 'builder', 'reviewer', 'debugger'];
  for (const id of agentOrder) {
    const h = document.createElement('div');
    agentHolders[id] = h;
    squadEl.appendChild(h);
  }
  squadEl.appendChild(finalHolder);

  // Start SSE
  try {
    const res = await fetch('/api/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ apiKey, model, prompt, history })
    });

    if (!res.ok) {
      const txt = await res.text();
      toast(`Error: ${txt}`, 'error');
      running = false;
      document.getElementById('send-btn').disabled = false;
      document.getElementById('status-hint').textContent = '// error';
      return;
    }

    const reader  = res.body.getReader();
    const decoder = new TextDecoder();
    let   buf     = '';
    let   currentAgent = null;
    let   agentOutputs = {};
    let   agentBodyEls = {};

    function getOrCreateAgentEl(agentId) {
      if (agentHolders[agentId].children.length) return agentBodyEls[agentId];

      const meta   = AGENTS_META[agentId];
      const wrapper = document.createElement('div');
      wrapper.className = 'agent-output';
      wrapper.innerHTML = `
        <div class="agent-output-header" onclick="toggleAgentOutput('${agentId}')">
          <div class="agent-output-header-left">
            <div class="agent-output-dot" style="background:${meta.color}"></div>
            <div class="agent-output-name">${meta.name}</div>
            <div class="agent-output-role">${meta.role}</div>
          </div>
          <div class="agent-output-status working" id="ao-status-${agentId}">working...</div>
        </div>
        <div class="agent-output-body open" id="ao-body-${agentId}">
          <div class="md-output" id="ao-text-${agentId}"></div>
        </div>
      `;
      agentHolders[agentId].appendChild(wrapper);
      agentBodyEls[agentId] = document.getElementById(`ao-text-${agentId}`);
      return agentBodyEls[agentId];
    }

    function getOrCreateFinalEl() {
      if (finalHolder.children.length) return document.getElementById('final-text');
      finalHolder.innerHTML = `
        <div class="final-block">
          <div class="final-header">
            <div class="agent-output-dot" style="background:${AGENTS_META.supervisor.color}"></div>
            <div class="final-badge">Final Output</div>
            <div class="final-title">The Lead — synthesis</div>
            <button class="copy-btn" onclick="copyFinal()">Copy</button>
          </div>
          <div class="final-body">
            <div class="md-output" id="final-text"></div>
          </div>
        </div>
      `;
      return document.getElementById('final-text');
    }

    // Read SSE stream
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buf += decoder.decode(value, { stream: true });
      const parts = buf.split('\n\n');
      buf = parts.pop();

      for (const part of parts) {
        if (!part.trim()) continue;
        const lines = part.split('\n');
        let event = 'message', data = '';
        for (const line of lines) {
          if (line.startsWith('event: ')) event = line.slice(7).trim();
          if (line.startsWith('data: '))  data  = line.slice(6).trim();
        }
        if (!data) continue;

        let payload;
        try { payload = JSON.parse(data); } catch { continue; }

        switch (event) {

          case 'phase': {
            const { agent, status } = payload;
            if (status === 'thinking')    setAgentStatus('supervisor', 'working', '// planning...');
            if (status === 'synthesizing') setAgentStatus('supervisor', 'working', '// synthesizing...');
            if (status === 'working') {
              setAgentStatus(agent, 'working', '// working...');
              currentAgent = agent;
              getOrCreateAgentEl(agent);
            }
            document.getElementById('status-run').innerHTML =
              `<div class="spinner"></div><span>${agent} ${status}</span>`;
            break;
          }

          case 'plan': {
            const { plan } = payload;
            if (!plan) break;
            setAgentStatus('supervisor', 'done', '// plan ready');

            let tasksHtml = '';
            if (plan.tasks) {
              for (const t of plan.tasks) {
                const meta = AGENTS_META[t.agent] || {};
                tasksHtml += `
                  <div class="plan-task">
                    <span class="plan-task-agent" style="background:${meta.color}18;color:${meta.color};border:1px solid ${meta.color}30">${t.agent}</span>
                    <span class="plan-task-text">${escHtml(t.task)}</span>
                  </div>
                `;
              }
            }

            planHolder.innerHTML = `
              <div class="plan-card">
                <div class="plan-header">
                  <span class="plan-header-badge">Build Plan</span>
                  <span class="plan-title">${escHtml(plan.summary || 'Squad plan')}</span>
                </div>
                <div class="plan-tasks">${tasksHtml}</div>
              </div>
            `;
            break;
          }

          case 'delta': {
            const { agent, delta } = payload;
            if (!delta) break;

            if (agent === 'supervisor' && finalHolder.children.length === 0) {
              // First supervisor delta = synthesis
              currentAgent = 'supervisor_final';
            }

            if (agent === 'supervisor' && currentAgent === 'supervisor_final') {
              const el = getOrCreateFinalEl();
              agentOutputs['final'] = (agentOutputs['final'] || '') + delta;
              el.innerHTML = renderMd(agentOutputs['final']).replace('<div class="md-output">', '').replace('</div>', '');
            } else if (agent !== 'supervisor') {
              const el = getOrCreateAgentEl(agent);
              agentOutputs[agent] = (agentOutputs[agent] || '') + delta;
              el.innerHTML = renderMd(agentOutputs[agent]).replace('<div class="md-output">', '').replace('</div>', '');
            }

            chat.scrollTop = chat.scrollHeight;
            break;
          }

          case 'agent_done': {
            const { agent } = payload;
            const statusEl = document.getElementById(`ao-status-${agent}`);
            if (statusEl) {
              statusEl.className = 'agent-output-status done';
              statusEl.textContent = 'done';
            }
            setAgentStatus(agent, 'done', '// done');
            break;
          }

          case 'done': {
            setAgentStatus('supervisor', 'done', '// complete');
            document.getElementById('status-run').textContent = '// complete';
            document.getElementById('status-hint').textContent = '// done';

            // Add to history
            history.push({ role: 'user', content: prompt });
            history.push({ role: 'assistant', content: agentOutputs['final'] || '' });
            // Keep last 10 turns
            if (history.length > 20) history = history.slice(-20);

            addHistoryItem(prompt);
            break;
          }

          case 'error': {
            toast(payload.message || 'Squad error', 'error');
            document.getElementById('status-hint').textContent = '// error';
            document.getElementById('status-run').textContent  = '// error';
            break;
          }
        }
      }
    }

  } catch (e) {
    toast(`Failed: ${e.message}`, 'error');
    document.getElementById('status-hint').textContent = '// failed';
  }

  running = false;
  document.getElementById('send-btn').disabled = false;
  resetAgentStatuses();
}

// ── ADD HISTORY ITEM
function addHistoryItem(prompt) {
  const list = document.getElementById('history-list');
  if (!list) return;
  const item = document.createElement('div');
  item.className = 'history-item';
  item.innerHTML = `
    <div class="history-item-text">${escHtml(prompt.slice(0, 40))}</div>
    <div class="history-item-time">${new Date().toLocaleTimeString()}</div>
  `;
  list.insertBefore(item, list.firstChild);
}

// ── TOGGLE AGENT OUTPUT
window.toggleAgentOutput = function(agentId) {
  const body = document.getElementById(`ao-body-${agentId}`);
  if (body) body.classList.toggle('open');
};

// ── COPY FINAL
window.copyFinal = function() {
  const el = document.getElementById('final-text');
  if (!el) return;
  navigator.clipboard.writeText(el.innerText).then(() => toast('Copied', 'success'));
};

// ── ESC HTML
function escHtml(str) {
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── BOOT
document.addEventListener('DOMContentLoaded', () => {
  if (apiKey) {
    renderShell();
  } else {
    renderSetup();
  }
});
