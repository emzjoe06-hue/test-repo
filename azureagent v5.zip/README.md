# Azure Agent

Agentic AI assistant that runs on your local machine (Termux-friendly).

## Setup

**IMPORTANT — Install in Termux home, not in /storage/Download:**
```bash
cp -r /storage/emulated/0/Download/azure-agent ~/azure-agent
cd ~/azure-agent/azure-agent-new
npm install
node server.js
```

## Access from another device on the same Wi-Fi

1. Find your phone's IP: Settings → Wi-Fi → your network → IP Address
2. Open on desktop: `http://192.168.x.xxx:3000`

## Custom port

```bash
PORT=8080 node server.js
```

## Features

- Chat with persistence (survives page refresh)
- Clear chat button (trash icon in topbar)
- Stop/abort button during generation
- File attachments — clip icon in input
- Syntax highlighting in code blocks
- Diff viewer when agent writes files
- Custom persona editor
- Iteration counter in status pill (e.g. iter 2/10)
- WebSocket transport (more reliable than SSE, especially on mobile)
- Binds to 0.0.0.0 — accessible from any device on your network

## API key

Optional. Only Azure Auto model requires one.
Set as env var: `KILO_API_KEY=your_key node server.js`
