#!/bin/bash
PORT=${PORT:-3000}
echo "Starting Azure Agent on port $PORT..."
echo "Access: http://localhost:$PORT"
node server.js
