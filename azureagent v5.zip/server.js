const express = require('express');
const { exec } = require('child_process');
const fs = require('fs').promises;
const path = require('path');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.static(path.join(__dirname, 'public')));

const WORKSPACE_ROOT = path.join(__dirname, 'workspace');
const HISTORY_FILE = (tabName) => path.join(WORKSPACE_ROOT, tabName, '.chat-history.json');
const SETTINGS_FILE = path.join(__dirname, '.settings.json');

// ===== MODEL CONFIGURATION =====
const AZURE_MODELS = {
  'azure-composer':       'bytedance-seed/dola-seed-2.0-pro:free',
  'azure-coder':          'x-ai/grok-code-fast-1:optimized:free',
  'azure-coder-instruct': 'nvidia/nemotron-3-super-120b-a12b:free',
  'azure-code-xl':        'arcee-ai/trinity-large-thinking:free',
  'azure-omni':           'openrouter/free',
  'azure-auto':           'kilo-auto/free',
};

// Model health status
const modelHealth = {
  'azure-composer': { status: 'unknown', lastCheck: 0, failCount: 0 },
  'azure-coder': { status: 'unknown', lastCheck: 0, failCount: 0 },
  'azure-coder-instruct': { status: 'unknown', lastCheck: 0, failCount: 0 },
  'azure-code-xl': { status: 'unknown', lastCheck: 0, failCount: 0 },
  'azure-omni': { status: 'unknown', lastCheck: 0, failCount: 0 },
  'azure-auto': { status: 'unknown', lastCheck: 0, failCount: 0 },
};

const AZURE_MODEL_INFO = [
  { id: 'azure-composer',       name: 'Azure Composer',       desc: 'General purpose, fast responses',              requiresKey: false, category: 'free' },
  { id: 'azure-coder',          name: 'Azure Coder',          desc: 'Optimized for code tasks',                     requiresKey: false, category: 'free' },
  { id: 'azure-coder-instruct', name: 'Azure Coder Instruct', desc: 'Large model, deep reasoning',                  requiresKey: false, category: 'free' },
  { id: 'azure-code-xl',        name: 'Azure Code XL',        desc: 'Extended thinking, complex problems',          requiresKey: false, category: 'free' },
  { id: 'azure-omni',           name: 'Azure Omni',           desc: 'Best available free model',                    requiresKey: false, category: 'free' },
  { id: 'azure-auto',           name: 'Azure Auto',           desc: 'Auto-routes to best model (API key required)', requiresKey: true,  category: 'premium' },
];

// ===== SETTINGS PERSISTENCE =====
async function loadSettings() {
  try {
    const raw = await fs.readFile(SETTINGS_FILE, 'utf-8');
    return JSON.parse(raw);
  } catch { return {}; }
}

async function saveSettings(settings) {
  try {
    await fs.writeFile(SETTINGS_FILE, JSON.stringify(settings, null, 2), 'utf-8');
  } catch (e) { console.error('Settings save error:', e.message); }
}

app.get('/api/settings', async (req, res) => {
  try {
    const settings = await loadSettings();
    // Mask API keys for security (but keep a flag for whether they exist)
    const safeSettings = {
      ...settings,
      hasApiKey: !!settings.apiKey,
      apiKey: settings.apiKey ? '••••••••' : '',
    };
    res.json(safeSettings);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/settings', async (req, res) => {
  try {
    const current = await loadSettings();
    const updates = req.body;
    // Don't overwrite actual API key if they sent masked version
    if (updates.apiKey === '••••••••') delete updates.apiKey;
    const merged = { ...current, ...updates };
    await saveSettings(merged);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/models/status', (req, res) => {
  res.json({ models: AZURE_MODEL_INFO, health: modelHealth });
});

// ===== WORKSPACE HELPERS =====
async function ensureWorkspace(tabName) {
  const dir = path.join(WORKSPACE_ROOT, tabName);
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

async function listDir(base, current) {
  const entries = await fs.readdir(current, { withFileTypes: true });
  let result = [];
  for (const entry of entries) {
    if (entry.name.startsWith('.')) continue;
    const fullPath = path.join(current, entry.name);
    const relPath = path.relative(base, fullPath);
    if (entry.isDirectory()) {
      result.push({ name: relPath, type: 'dir' });
      result = result.concat(await listDir(base, fullPath));
    } else {
      result.push({ name: relPath, type: 'file' });
    }
  }
  return result;
}

async function loadHistory(tabName) {
  try {
    await ensureWorkspace(tabName);
    const raw = await fs.readFile(HISTORY_FILE(tabName), 'utf-8');
    return JSON.parse(raw);
  } catch { return []; }
}

async function saveHistory(tabName, messages) {
  try {
    await ensureWorkspace(tabName);
    await fs.writeFile(HISTORY_FILE(tabName), JSON.stringify(messages, null, 2), 'utf-8');
  } catch (e) { console.error('History save error:', e.message); }
}

// ===== API ROUTES =====
app.get('/api/models', (req, res) => res.json(AZURE_MODEL_INFO));

app.get('/api/workspace/:tab/files', async (req, res) => {
  try {
    const dir = await ensureWorkspace(req.params.tab);
    res.json({ files: await listDir(dir, dir) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/workspace/:tab/file', async (req, res) => {
  try {
    const dir = await ensureWorkspace(req.params.tab);
    const filePath = path.join(dir, req.query.path || '');
    if (!filePath.startsWith(dir)) return res.status(403).json({ error: 'Forbidden' });
    res.json({ content: await fs.readFile(filePath, 'utf-8') });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/workspace/:tab/file', async (req, res) => {
  try {
    const dir = await ensureWorkspace(req.params.tab);
    const filePath = path.join(dir, req.body.path || '');
    if (!filePath.startsWith(dir)) return res.status(403).json({ error: 'Forbidden' });
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, req.body.content || '', 'utf-8');
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.get('/api/workspace/:tab/history', async (req, res) => {
  try { res.json({ history: await loadHistory(req.params.tab) }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/workspace/:tab/history', async (req, res) => {
  try { await saveHistory(req.params.tab, req.body.messages || []); res.json({ ok: true }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/workspace/:tab/history', async (req, res) => {
  try { await saveHistory(req.params.tab, []); res.json({ ok: true }); }
  catch (e) { res.status(500).json({ error: e.message }); }
});

// ===== ACTION PARSING =====
function parseActions(text) {
  const actions = [];
  for (const m of [...text.matchAll(/<cmd>([\s\S]*?)<\/cmd>/g)])
    actions.push({ type: 'cmd', content: m[1].trim(), detail: m[1].trim().substring(0, 80) });
  for (const m of [...text.matchAll(/<write\s+path="([^"]+)">([\s\S]*?)<\/write>/g)])
    actions.push({ type: 'write', path: m[1], content: m[2], detail: m[1] });
  for (const m of [...text.matchAll(/<delete\s+path="([^"]+)"\s*\/?>/g)])
    actions.push({ type: 'delete', path: m[1], detail: m[1] });
  for (const m of [...text.matchAll(/<read\s+path="([^"]+)"\s*\/?>/g)])
    actions.push({ type: 'read', path: m[1], detail: m[1] });

  const cleanText = text
    .replace(/<think>[\s\S]*?<\/think>/g, '')
    .replace(/<cmd>[\s\S]*?<\/cmd>/g, '')
    .replace(/<write\s+path="[^"]+">([\s\S]*?)<\/write>/g, '')
    .replace(/<delete\s+path="[^"]+"\s*\/?>/g, '')
    .replace(/<read\s+path="[^"]+"\s*\/?>/g, '')
    .trim();

  return { cleanText, actions };
}

async function fileExists(filePath) {
  try { await fs.access(filePath); return true; } catch { return false; }
}

async function executeAction(action, workspaceDir) {
  if (action.type === 'cmd') {
    return new Promise((resolve) => {
      exec(action.content, { cwd: workspaceDir, timeout: 30000 }, (err, stdout, stderr) => {
        let out = '';
        if (stdout) out += stdout;
        if (stderr) out += stderr;
        if (err && !out) out = err.message;
        resolve(out.substring(0, 3000) || '(no output)');
      });
    });
  }
  if (action.type === 'write') {
    const fp = path.join(workspaceDir, action.path);
    if (!fp.startsWith(workspaceDir)) throw new Error('Path outside workspace');
    const existed = await fileExists(fp);
    await fs.mkdir(path.dirname(fp), { recursive: true });
    await fs.writeFile(fp, action.content, 'utf-8');
    action.fileOp = existed ? 'edited' : 'created';
    return `File ${action.fileOp}: ${action.path} (${action.content.length} bytes)`;
  }
  if (action.type === 'delete') {
    const fp = path.join(workspaceDir, action.path);
    if (!fp.startsWith(workspaceDir)) throw new Error('Path outside workspace');
    await fs.unlink(fp);
    action.fileOp = 'deleted';
    return `File deleted: ${action.path}`;
  }
  if (action.type === 'read') {
    const fp = path.join(workspaceDir, action.path);
    if (!fp.startsWith(workspaceDir)) throw new Error('Path outside workspace');
    return (await fs.readFile(fp, 'utf-8')).substring(0, 3000);
  }
  return 'Unknown action';
}

// ===== WEBSOCKET CHAT HANDLING =====
const activeJobs = new Map();

wss.on('connection', (ws) => {
  ws.on('message', async (raw) => {
    let payload;
    try { payload = JSON.parse(raw); } catch { return; }

    const send = (data) => { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(data)); };

    if (payload.type === 'abort') {
      const ctrl = activeJobs.get(ws);
      if (ctrl) { ctrl.abort(); activeJobs.delete(ws); }
      send({ type: 'aborted' });
      return;
    }

    if (payload.type === 'chat') {
      const { messages, model, apiKey, tab, customSystem } = payload;
      const realModel = AZURE_MODELS[model] || 'openrouter/free';
      const workspaceDir = await ensureWorkspace(tab || 'default');

      const ctrl = new AbortController();
      activeJobs.set(ws, ctrl);

      const baseSystem = `You are an autonomous software engineer and expert UI/UX developer. You operate inside a sandboxed workspace on the user's machine. You think in systems, act decisively, and ship complete work — not stubs, not placeholders, not "here's a starting point."

WORKSPACE: ${workspaceDir}
MODEL: ${model} (${realModel})

═══════════════════════════════════════════
AVAILABLE ACTIONS
═══════════════════════════════════════════

<cmd>shell command here</cmd>
  Run any shell command in the workspace directory. Use for: installing packages,
  running scripts, compiling, running tests, checking files, git operations.
  Output is capped at 3000 chars. Chain commands with && when order matters.

<write path="relative/path/to/file.ext">
full file content here
</write>
  Create or overwrite a file. Always write the COMPLETE file — never partial content,
  never "rest of file unchanged." If you're editing, read it first, then write the full
  modified version. Path is relative to workspace root.

<read path="relative/path/to/file.ext"/>
  Read a file from workspace. Do this before editing so you have the current state.
  Output capped at 3000 chars.

<delete path="relative/path/to/file.ext"/>
  Permanently delete a file. Confirm it's not needed before deleting.

<think>
your internal reasoning here
</think>
  Private reasoning scratchpad — hidden from the user. Use before complex decisions:
  planning architecture, debugging a failure, deciding between approaches.
  Think out loud here, then act with confidence.

═══════════════════════════════════════════
HOW TO WORK
═══════════════════════════════════════════

You operate in an agentic loop. After each batch of actions, you receive the results
and continue until the task is fully complete. Follow this discipline:

1. UNDERSTAND BEFORE ACTING
   Read the relevant files before modifying them. If the user's request is ambiguous,
   make a reasonable decision and state your assumption — don't ask clarifying questions
   unless the task literally cannot proceed without an answer.

2. PLAN IN <think> BLOCKS
   For any task with more than 2 steps, write a concise plan in a <think> block first.
   Identify: what files need to change, what commands to run, what the end state looks like.

3. ACT COMPLETELY
   Complete the entire task in one session. Don't stop halfway and say "let me know if
   you want me to continue." If something fails, debug it and fix it. If a file needs
   creating, create it fully. If tests fail, investigate and fix.

4. VERIFY YOUR WORK
   After writing code, run it. After installing packages, check they're importable.
   After building, confirm the output exists. Don't ship blind.

5. SUMMARIZE CLEARLY
   End every completed task with a tight summary: what was built, what was changed,
   what commands to run. Use a simple list. No fluff.

═══════════════════════════════════════════
ENGINEERING STANDARDS
═══════════════════════════════════════════

GENERAL
• Modern JS (ES2022+) / Python 3.10+ / use whatever language fits the task
• async/await everywhere — no .then() chains, no callback nesting
• Error handling on every async operation — never let a promise float unhandled
• No console.log in delivered code — use proper logging or remove debug output
• No TODO comments, no lorem ipsum, no placeholder functions
• If you use a library, import it correctly — check it's installed before using it
• Environment variables for secrets — never hardcode API keys or credentials

BACKEND (Node/Express)
• Routes grouped by resource with comment headers
• Consistent response shape: { ok: true, data: ... } or { error: 'message' }
• Path traversal protection on all file operations
• Middleware before routes, listen() at the bottom
• JSON file persistence: load on startup, write on mutation — never read per-request

FRONTEND
• Single-page apps: one root container, JS renders views
• State at the top, render functions in the middle, listeners at the bottom
• Full re-render of containers — don't surgically patch DOM unless you have a clear reason
• Every async fetch is wrapped in try/catch with a visible error state for the user
• Keyboard accessible: Enter submits forms, Escape closes modals, Tab navigates

═══════════════════════════════════════════
UI/UX DESIGN SYSTEM — DarkNode
═══════════════════════════════════════════

When building any interface, apply the DarkNode design system exactly as specified below.
This is not a suggestion. Every UI output must conform to these rules.

PHILOSOPHY
  A working tool that looks exceptional. Density without clutter.
  Every pixel earns its place. No decoration for decoration's sake.

FORBIDDEN — never use any of these:
  • Gradients of any kind (no linear-gradient, no radial-gradient, no background-image for color)
  • Emojis — zero, none, not even one
  • border-radius: 99px pill buttons
  • Glassmorphism / backdrop-filter blur on panels (modals only, max blur(16px))
  • Animations longer than 250ms (except page-level transitions)
  • Hardcoded hex colors — every color must be a CSS variable
  • Glow box-shadows as hover signals — use border-color change instead
  • AI-generated aesthetic patterns: glowing orbs, mesh backgrounds, hero gradient text

CSS DESIGN TOKENS — use verbatim:

  :root {
    /* Backgrounds */
    --bg:   #060607;
    --bg1:  #0a0a0c;
    --bg2:  #0f0f12;
    --bg3:  #141418;
    --bg4:  #1a1a1f;
    --bg5:  #212128;

    /* Borders */
    --line:  #16161a;
    --line2: #1e1e24;
    --line3: #2a2a34;

    /* Text */
    --t0: #f0f0f4;
    --t1: #8a8a9a;
    --t2: #44444e;
    --t3: #222228;

    /* Accent (achromatic unless domain demands color) */
    --ac:  #f0f0f4;
    --ac2: #b0b0be;
    --ac3: #505060;

    /* Semantic */
    --red:   #e05555;
    --red2:  #ff7070;
    --grn:   #34a86a;
    --grn2:  #48cc84;
    --amber: #d48830;

    /* Typography */
    --mono: 'JetBrains Mono', monospace;
    --sans: 'Inter', sans-serif;

    /* Geometry */
    --r:  5px;
    --r2: 8px;
    --r3: 12px;
    --r4: 16px;

    /* Elevation */
    --shadow:  0 4px 24px rgba(0,0,0,.7);
    --shadow2: 0 20px 80px rgba(0,0,0,.9);
  }

TYPOGRAPHY
  Fonts: Inter (sans) + JetBrains Mono (mono) — always from Google Fonts
  
  Use SANS (Inter) for: body text, button labels, names, anything a user reads
  Use MONO (JetBrains Mono) for: labels, metadata, IDs, counts, status text,
    code/paths, section eyebrows — always 8–10px, letter-spacing: .12em, uppercase

  Scale:
    Page title:     24–32px, weight 300, letter-spacing -.03em, color var(--t0)
    Section label:  font-family mono, 8px, letter-spacing .12em, uppercase, var(--t2)
    Body:           13px, var(--t1), line-height 1.6
    Small meta:     mono, 9–10px, var(--t2)
    Ghost/empty:    mono, 10–11px, var(--t3)

COMPONENTS

  Buttons:
    .mbtn { height:32px; display:inline-flex; align-items:center; gap:4px;
      padding:0 14px; background:var(--bg3); border:1px solid var(--line2);
      color:var(--t1); font-size:12px; font-family:var(--sans); font-weight:500;
      cursor:pointer; border-radius:var(--r2); transition:all .1s; }
    .mbtn:hover { border-color:var(--line3); color:var(--t0); background:var(--bg4); }
    .mbtn.primary { background:var(--t0); border-color:var(--t0); color:var(--bg); font-weight:600; }
    .mbtn.primary:hover { background:var(--ac2); border-color:var(--ac2); }
    .mbtn.danger { color:var(--red2); border-color:rgba(224,85,85,.15); background:rgba(224,85,85,.04); }
    .mbtn.danger:hover { background:rgba(224,85,85,.1); }
    Max border-radius on buttons: var(--r2). Never pill.

  Inputs:
    .minput { width:100%; padding:10px 12px; background:var(--bg3); border:1px solid var(--line2);
      color:var(--t0); font-size:13px; font-family:var(--sans); outline:none;
      border-radius:var(--r2); transition:border-color .14s; }
    .minput::placeholder { color:var(--t3); }
    .minput:focus { border-color:var(--line3); background:var(--bg4); }

  Modals:
    Overlay: rgba(0,0,0,.75) + backdrop-filter:blur(16px)
    Modal: background var(--bg2), border var(--line3), border-radius var(--r4)
    Animation: modalIn — scale(.96) + translateY(10px) → normal, 200ms spring easing

  Toasts:
    Fixed bottom-center, mono 10px font, var(--bg4) background, var(--line3) border
    Status dot: 5px circle, grn2 for success, red2 for error
    Auto-dismiss at 3200ms

  Scrollbar:
    ::-webkit-scrollbar { width:3px; }
    thumb: var(--line3), hover: var(--ac3)

  Status dot:
    5px circle, .online → var(--grn2) + glow, .offline → var(--t3)

  Empty states:
    Centered column, SVG icon (var(--t3), 50% opacity), 14px var(--t2) text,
    mono 9px var(--t3) hint below

ANIMATIONS
  All transitions: 100–200ms
  Enter animations: 200–250ms with cubic-bezier(.16,1,.3,1)
  Hover lift (cards): transform: translateY(-1px)
  Spinner: 14px circle, border-top var(--t1), 0.7s linear spin
  Never use box-shadow change as hover signal

APP SHELL PATTERN
  height:100vh; overflow:hidden; display:grid;
  grid-template-rows: 48px 1fr;
  grid-template-columns: 204px 1fr [optional: right-panel-width];
  Topbar: var(--bg1), border-bottom var(--line)
  Sidebar: var(--bg1), border-right var(--line)
  Main: var(--bg), flex:1, overflow-y:auto

CODE STYLE
  HTML: no inline styles, no inline handlers, IDs for JS targets, classes for styling
  CSS: group by position→display→size→spacing→typography→color→effects→transitions
       use /* ══ SECTION ══ */ comment blocks, never !important, flat selectors
  JS:  state at top (// ── STATE), then fetch helpers, then render functions,
       then single DOMContentLoaded block at bottom
       loadX() = fetch, renderX() = DOM update, doX() = user action, openX()/closeX() = modals

═══════════════════════════════════════════
DELIVERY CHECKLIST (run mentally before finalizing)
═══════════════════════════════════════════

  [ ] No hardcoded colors in CSS
  [ ] No gradients anywhere
  [ ] No emojis anywhere
  [ ] All fonts via CSS variables
  [ ] All animations ≤250ms
  [ ] Mobile breakpoint exists at bottom of CSS
  [ ] Toast system wired up
  [ ] Empty states for every list
  [ ] Loading states for every async op
  [ ] Section comments in CSS and JS
  [ ] No console.log in delivered code
  [ ] Scrollbar overridden
  [ ] Every button/input has hover and focus state
  [ ] Paths verified — no path traversal vulnerabilities
  [ ] Packages installed before import`;

      const finalSystem = customSystem ? `${customSystem}\n\n---\n\n${baseSystem}` : baseSystem;
      const allMessages = [{ role: 'system', content: finalSystem }, ...messages];
      let iterations = 0;
      const MAX_ITERATIONS = 10;
      let lastError = null;

      try {
        while (iterations < MAX_ITERATIONS) {
          if (ctrl.signal.aborted) break;
          iterations++;
          send({ type: 'iteration', current: iterations, max: MAX_ITERATIONS });

          const headers = { 'Content-Type': 'application/json' };
          if (apiKey) headers['Authorization'] = `Bearer ${apiKey}`;
          else if (process.env.KILO_API_KEY) headers['Authorization'] = `Bearer ${process.env.KILO_API_KEY}`;

          let response;
          let fetchError = null;

          // Retry logic with exponential backoff for Azure Auto model
          const maxRetries = model === 'azure-auto' ? 3 : 1;
          let attempt = 0;

          while (attempt < maxRetries) {
            try {
              response = await fetch('https://api.kilo.ai/api/gateway/chat/completions', {
                method: 'POST',
                headers,
                signal: ctrl.signal,
                body: JSON.stringify({ model: realModel, messages: allMessages, stream: true, max_tokens: 4096 }),
              });
              break; // Success, exit retry loop
            } catch (e) {
              attempt++;
              fetchError = e;
              if (attempt < maxRetries) {
                const delay = Math.pow(2, attempt) * 1000; // Exponential backoff
                send({ type: 'status', message: `Retrying... (attempt ${attempt + 1}/${maxRetries})` });
                await new Promise(resolve => setTimeout(resolve, delay));
              }
            }
          }

          if (!response || !response.ok) {
            const errBody = response ? await response.text() : (fetchError?.message || 'Network error');
            lastError = errBody;

            // Mark model as having issues
            if (modelHealth[model]) {
              modelHealth[model].failCount++;
              modelHealth[model].status = modelHealth[model].failCount >= 3 ? 'degraded' : 'unknown';
            }

            send({ type: 'error', content: `API Error (${response?.status || 'no response'}): ${errBody}`, model });
            break;
          }

          // Mark model as healthy
          if (modelHealth[model]) {
            modelHealth[model].failCount = 0;
            modelHealth[model].status = 'healthy';
          }

          let assistantMsg = '';
          let lastSentCleanLen = 0;
          let streamEnded = false;

          // Streaming with timeout protection
          const streamTimeout = setTimeout(() => {
            if (!streamEnded) {
              send({ type: 'warning', content: 'Stream timeout - processing may continue' });
            }
          }, 60000); // 60 second timeout

          try {
            const reader = response.body.getReader();
            const decoder = new TextDecoder();
            let buffer = '';

            while (true) {
              if (ctrl.signal.aborted) break;
              try {
                const { done, value } = await reader.read();
                if (done) { streamEnded = true; break; }

                buffer += decoder.decode(value, { stream: true });
                const lines = buffer.split('\n');
                buffer = lines.pop();

                for (const line of lines) {
                  const trimmed = line.trim();
                  if (!trimmed || trimmed === 'data: [DONE]') {
                    streamEnded = true;
                    continue;
                  }
                  if (!trimmed.startsWith('data: ')) continue;
                  try {
                    const chunk = JSON.parse(trimmed.slice(6));
                    const delta = chunk.choices?.[0]?.delta?.content || '';
                    assistantMsg += delta;

                    // Stream cleaned text in real time
                    const { cleanText } = parseActions(assistantMsg);
                    if (cleanText.length > lastSentCleanLen) {
                      send({ type: 'stream', content: cleanText });
                      lastSentCleanLen = cleanText.length;
                    }
                  } catch {}
                }
              } catch (e) {
                if (e.name === 'AbortError') break;
                // Continue on read errors
              }
            }
          } finally {
            clearTimeout(streamTimeout);
          }

          const { cleanText, actions } = parseActions(assistantMsg);
          send({ type: 'text_done', content: cleanText });
          allMessages.push({ role: 'assistant', content: assistantMsg });

          if (actions.length === 0) break;

          let toolResults = '';
          for (const action of actions) {
            if (ctrl.signal.aborted) break;
            send({ type: 'action', action: action.type, detail: action.detail, path: action.path });
            let result = '';
            try { result = await executeAction(action, workspaceDir); }
            catch (e) { result = `ERROR: ${e.message}`; }
            send({
              type: 'result',
              action: action.type,
              detail: action.detail,
              content: result,
              fileOp: action.fileOp || null,
              path: action.path || null,
            });
            toolResults += `\n[${action.type.toUpperCase()} RESULT]\n${result}\n`;
          }

          allMessages.push({
            role: 'user',
            content: `Action results:${toolResults}\nContinue or summarize what was accomplished.`,
          });
        }
      } catch (e) {
        if (e.name !== 'AbortError') {
          lastError = e.message;
          send({ type: 'error', content: e.message });
        }
      }

      if (lastError) {
        send({ type: 'final_error', content: lastError, model });
      }
      send({ type: 'done' });
      activeJobs.delete(ws);
    }
  });

  ws.on('close', () => {
    const ctrl = activeJobs.get(ws);
    if (ctrl) ctrl.abort();
    activeJobs.delete(ws);
  });

  ws.on('error', (e) => {
    console.error('WebSocket error:', e.message);
  });
});

const PORT = process.env.PORT || 2000;
server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n🏢 Azure Agent v4 → http://localhost:${PORT}`);
  console.log(`Workspace: ${WORKSPACE_ROOT}`);
  console.log(`Settings: ${SETTINGS_FILE}`);
});