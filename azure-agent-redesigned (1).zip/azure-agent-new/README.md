# ⚡ Azure Agent

A locally hosted agentic AI interface powered by free models via Kilo AI Gateway.

## Features
- 🤖 **Fully agentic** — runs shell commands, writes/reads files, builds projects autonomously
- 🪟 **Multi-tab workspaces** — each tab gets its own isolated `/workspace/tabname/` directory
- 🆓 **Free models** — all masked as Azure-branded model names
- 💻 **Beautiful UI** — dark cyberpunk terminal aesthetic
- 📁 **File browser** — live workspace file tree + viewer
- 🖥️ **Terminal log** — see every command the agent runs in real time

## Models Available

| Azure Name | Description |
|---|---|
| Azure Composer | Fast general purpose (ByteDance Dola Seed) |
| Azure Coder | Code-optimized (xAI Grok Code Fast) |
| Azure Coder Instruct | Large 120B model (NVIDIA Nemotron) |
| Azure Code XL | Extended thinking (Arcee Trinity) |
| Azure Omni | Best free auto-routed (OpenRouter free) |
| Azure Auto ★ | Intelligent routing (requires API key) |

## Setup

### Requirements
- Node.js 18+

### Start
```bash
cd azure-agent
npm install
npm start
```

Or just run:
```bash
bash start.sh
```

Then open: **http://localhost:3000**

### Optional: API Key
For **Azure Auto** model, you need a Kilo AI API key.
Enter it in the UI when prompted, or set env var:
```bash
KILO_API_KEY=your_key_here node server.js
```

## Agent Commands (built-in)
The agent can use these actions autonomously:
- `<cmd>...</cmd>` — run shell commands
- `<write path="...">...</write>` — write files to workspace
- `<read path="..."/>` — read files from workspace
- `<think>...</think>` — internal reasoning (not shown)

## Workspace
Files are stored at `./workspace/[tabname]/` relative to the server directory.
Each browser tab gets its own isolated workspace.
