#!/bin/bash
echo ""
echo "  ⚡ Azure Agent - Local AI Agent"
echo "  ================================"
echo ""

# Check node
if ! command -v node &> /dev/null; then
  echo "  ❌ Node.js is required. Install from https://nodejs.org"
  exit 1
fi

# Install deps if needed
if [ ! -d "node_modules" ]; then
  echo "  📦 Installing dependencies..."
  npm install
fi

echo "  🚀 Starting Azure Agent..."
echo ""
node server.js
