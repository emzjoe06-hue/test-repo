const express = require('express');
const { exec, spawn } = require('child_process');
const fs = require('fs').promises;
const path = require('path');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

const WORKSPACE_ROOT = path.join(__dirname, 'workspace');

// Model mapping - masked as Azure branded
const AZURE_MODELS = {
  'azure-composer': 'bytedance-seed/dola-seed-2.0-pro:free',
  'azure-coder': 'x-ai/grok-code-fast-1:optimized:free',
  'azure-coder-instruct': 'nvidia/nemotron-3-super-120b-a12b:free',
  'azure-code-xl': 'arcee-ai/trinity-large-thinking:free',
  'azure-omni': 'openrouter/free',
  'azure-auto': 'kilo-auto/free',
};

const AZURE_MODEL_INFO = [
  { id: 'azure-composer',       name: 'Azure Composer',        desc: 'General purpose, fast responses',        requiresKey: false },
  { id: 'azure-coder',          name: 'Azure Coder',           desc: 'Optimized for code tasks',               requiresKey: false },
  { id: 'azure-coder-instruct', name: 'Azure Coder Instruct',  desc: 'Large model, deep reasoning',            requiresKey: false },
  { id: 'azure-code-xl',        name: 'Azure Code XL',         desc: 'Extended thinking, complex problems',    requiresKey: false },
  { id: 'azure-omni',           name: 'Azure Omni',            desc: 'Best available free model',              requiresKey: false },
  { id: 'azure-auto',           name: 'Azure Auto',            desc: 'Auto-routes to best model (API key req)', requiresKey: true },
];

// Ensure workspace dir exists
async function ensureWorkspace(tabName) {
  const dir = path.join(WORKSPACE_ROOT, tabName);
  await fs.mkdir(dir, { recursive: true });
  return dir;
}

// API: list models
app.get('/api/models', (req, res) => {
  res.json(AZURE_MODEL_INFO);
});

// API: list workspace files
app.get('/api/workspace/:tab/files', async (req, res) => {
  try {
    const dir = await ensureWorkspace(req.params.tab);
    const files = await listDir(dir, dir);
    res.json({ files });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

async function listDir(base, current) {
  const entries = await fs.readdir(current, { withFileTypes: true });
  let result = [];
  for (const entry of entries) {
    const fullPath = path.join(current, entry.name);
    const relPath = path.relative(base, fullPath);
    if (entry.isDirectory()) {
      result.push({ name: relPath, type: 'dir' });
      result = result.concat(await listDir(base, fullPath));
    } else {
      result.push({ name: relPath, type: 'file' });
    }
  }
  return result;
}

// API: read file
app.get('/api/workspace/:tab/file', async (req, res) => {
  try {
    const dir = await ensureWorkspace(req.params.tab);
    const filePath = path.join(dir, req.query.path || '');
    if (!filePath.startsWith(dir)) return res.status(403).json({ error: 'Forbidden' });
    const content = await fs.readFile(filePath, 'utf-8');
    res.json({ content });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// API: write file
app.post('/api/workspace/:tab/file', async (req, res) => {
  try {
    const dir = await ensureWorkspace(req.params.tab);
    const filePath = path.join(dir, req.body.path || '');
    if (!filePath.startsWith(dir)) return res.status(403).json({ error: 'Forbidden' });
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, req.body.content || '', 'utf-8');
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// API: chat with agent (streaming via SSE)
app.post('/api/chat', async (req, res) => {
  const { messages, model, apiKey, tab, persona } = req.body;
  const realModel = AZURE_MODELS[model] || 'openrouter/free';
  const workspaceDir = await ensureWorkspace(tab || 'default');

  // Build system prompt
  const personaPrefix = persona ? `${persona}\n\n` : '';
  const systemPrompt = `${personaPrefix}You are an agentic AI assistant running on a local machine. Your workspace is: ${workspaceDir}

You can perform tasks by outputting special action blocks. The system will execute them and return results.

AVAILABLE ACTIONS - use these XML-like tags in your responses:

<cmd>shell command here</cmd>
→ Runs a shell command in the workspace directory. Output is returned to you.

<write path="relative/path/to/file">
file content here
</write>
→ Creates or overwrites a file in the workspace.

<read path="relative/path/to/file"/>
→ Reads a file from the workspace.

<think>your internal reasoning</think>
→ Think step by step before acting. Not shown to user.

RULES:
- Be proactive and autonomous. If a task requires multiple steps, do them all.
- After each action, you receive the result and can continue.
- Always confirm what you did and what happened.
- For complex tasks, break them into steps and execute each one.
- You can install packages, run scripts, create projects, browse the web via curl, etc.
- The workspace path is: ${workspaceDir}
- Be concise in your responses but thorough in your actions.`;

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  const sendEvent = (data) => {
    res.write(`data: ${JSON.stringify(data)}\n\n`);
  };

  try {
    const headers = { 'Content-Type': 'application/json' };
    if (apiKey) headers['Authorization'] = `Bearer ${apiKey}`;
    else if (process.env.KILO_API_KEY) headers['Authorization'] = `Bearer ${process.env.KILO_API_KEY}`;

    const allMessages = [{ role: 'system', content: systemPrompt }, ...messages];

    // Agentic loop
    let iterations = 0;
    const MAX_ITERATIONS = 10;

    while (iterations < MAX_ITERATIONS) {
      iterations++;

      const response = await fetch('https://api.kilo.ai/api/gateway/chat/completions', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          model: realModel,
          messages: allMessages,
          stream: false,
          max_tokens: 4096,
        }),
      });

      if (!response.ok) {
        const err = await response.text();
        sendEvent({ type: 'error', content: `API Error: ${err}` });
        break;
      }

      const data = await response.json();
      const assistantMsg = data.choices?.[0]?.message?.content || '';

      // Parse and execute actions
      const { cleanText, actions } = parseActions(assistantMsg);

      // Stream the clean text
      if (cleanText.trim()) {
        sendEvent({ type: 'text', content: cleanText });
      }

      allMessages.push({ role: 'assistant', content: assistantMsg });

      if (actions.length === 0) break; // No more actions, done

      // Execute actions and collect results
      let toolResults = '';
      for (const action of actions) {
        sendEvent({ type: 'action', action: action.type, detail: action.detail });

        let result = '';
        try {
          result = await executeAction(action, workspaceDir);
        } catch (e) {
          result = `ERROR: ${e.message}`;
        }

        sendEvent({ type: 'result', action: action.type, content: result });
        toolResults += `\n[${action.type.toUpperCase()} RESULT]\n${result}\n`;
      }

      // Feed results back
      allMessages.push({ role: 'user', content: `Action results:${toolResults}\nContinue with the task if needed, or summarize what was accomplished.` });
    }

    sendEvent({ type: 'done' });
    res.end();
  } catch (e) {
    sendEvent({ type: 'error', content: e.message });
    res.end();
  }
});

function parseActions(text) {
  const actions = [];

  // Extract <cmd>
  const cmdMatches = [...text.matchAll(/<cmd>([\s\S]*?)<\/cmd>/g)];
  for (const m of cmdMatches) {
    actions.push({ type: 'cmd', content: m[1].trim(), detail: m[1].trim().substring(0, 60) });
  }

  // Extract <write>
  const writeMatches = [...text.matchAll(/<write\s+path="([^"]+)">([\s\S]*?)<\/write>/g)];
  for (const m of writeMatches) {
    actions.push({ type: 'write', path: m[1], content: m[2], detail: m[1] });
  }

  // Extract <read>
  const readMatches = [...text.matchAll(/<read\s+path="([^"]+)"\s*\/?>/g)];
  for (const m of readMatches) {
    actions.push({ type: 'read', path: m[1], detail: m[1] });
  }

  // Remove action tags and <think> blocks from display text
  let cleanText = text
    .replace(/<think>[\s\S]*?<\/think>/g, '')
    .replace(/<cmd>[\s\S]*?<\/cmd>/g, '')
    .replace(/<write\s+path="[^"]+">[\s\S]*?<\/write>/g, '')
    .replace(/<read\s+path="[^"]+"\s*\/?>/g, '')
    .trim();

  return { cleanText, actions };
}

async function executeAction(action, workspaceDir) {
  if (action.type === 'cmd') {
    return new Promise((resolve) => {
      exec(action.content, { cwd: workspaceDir, timeout: 30000 }, (err, stdout, stderr) => {
        let out = '';
        if (stdout) out += stdout;
        if (stderr) out += stderr;
        if (err && !out) out = err.message;
        resolve(out.substring(0, 3000) || '(no output)');
      });
    });
  }

  if (action.type === 'write') {
    const filePath = path.join(workspaceDir, action.path);
    if (!filePath.startsWith(workspaceDir)) throw new Error('Path outside workspace');
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, action.content, 'utf-8');
    return `File written: ${action.path} (${action.content.length} bytes)`;
  }

  if (action.type === 'read') {
    const filePath = path.join(workspaceDir, action.path);
    if (!filePath.startsWith(workspaceDir)) throw new Error('Path outside workspace');
    const content = await fs.readFile(filePath, 'utf-8');
    return content.substring(0, 3000);
  }

  return 'Unknown action';
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`\n🚀 Azure Agent running at http://localhost:${PORT}\n`);
  console.log(`Workspace root: ${WORKSPACE_ROOT}`);
});
